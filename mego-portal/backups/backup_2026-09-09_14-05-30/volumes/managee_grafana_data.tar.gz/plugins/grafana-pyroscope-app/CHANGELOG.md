# Changelog

## [2.3.0](https://github.com/grafana/profiles-drilldown/compare/v2.2.0...v2.3.0) (2026-08-21)


### 🎉 Features

* **call-tree:** remove feature flag (default=on) ([#1101](https://github.com/grafana/profiles-drilldown/issues/1101)) ([f527548](https://github.com/grafana/profiles-drilldown/commit/f527548ffe4453c6a72a6b5f481b5ea88d834003))


### 🐛 Bug Fixes

* **create-github-app-token:** version bump to 0.3.1 ([#1103](https://github.com/grafana/profiles-drilldown/issues/1103)) ([f535bb1](https://github.com/grafana/profiles-drilldown/commit/f535bb1e96103e4b814a3a8c47a4b7d78b7bf8ec))
* **deps:** bump pnpm overrides for CVE remediation ([#1098](https://github.com/grafana/profiles-drilldown/issues/1098)) ([75f9380](https://github.com/grafana/profiles-drilldown/commit/75f93805e905628763aacc2f9226bdf2c6de8470))
* **deps:** bump pnpm overrides for CVE remediation ([#1100](https://github.com/grafana/profiles-drilldown/issues/1100)) ([2c2730b](https://github.com/grafana/profiles-drilldown/commit/2c2730b6ee254f8861c574a08fdbd968043732c8))
* **deps:** override @hono/node-server ([#1076](https://github.com/grafana/profiles-drilldown/issues/1076)) ([e33002a](https://github.com/grafana/profiles-drilldown/commit/e33002aabd11091c5458b4d7da51c320a9a513ff))
* **deps:** resolve pnpm audit vulnerabilities ([#1073](https://github.com/grafana/profiles-drilldown/issues/1073)) ([6e2c46c](https://github.com/grafana/profiles-drilldown/commit/6e2c46c9d9b89c0a522fb3e5657aa5be1ca2f2f9))
* normalize string spanSelector in drilldown link builder ([#1069](https://github.com/grafana/profiles-drilldown/issues/1069)) ([1b7248f](https://github.com/grafana/profiles-drilldown/commit/1b7248f1086222127c913e3372cb111afa48a9dd))
* preserve span heatmap cell dimensions ([#1089](https://github.com/grafana/profiles-drilldown/issues/1089)) ([d51e13e](https://github.com/grafana/profiles-drilldown/commit/d51e13eeb8fd340b93358a41af7dca575ef354fa))
* **release-please:** Update release-please action version to v2.0.2 ([#1104](https://github.com/grafana/profiles-drilldown/issues/1104)) ([0f3c35f](https://github.com/grafana/profiles-drilldown/commit/0f3c35fead8f03f2668a541f6876beee85dcea40))
* **security/unknown/samples/rideshare:** update module github.com/klauspost/compress to v1.18.7 [security] ([#1070](https://github.com/grafana/profiles-drilldown/issues/1070)) ([a295445](https://github.com/grafana/profiles-drilldown/commit/a29544572a39f493af55d7715ea49177c57e185a))
* **security/unknown/samples/rideshare:** update module go.opentelemetry.io/otel to v1.44.0 [security] ([#1066](https://github.com/grafana/profiles-drilldown/issues/1066)) ([a712509](https://github.com/grafana/profiles-drilldown/commit/a712509ddf2ad0a542ca312e89f554955c8b96bf))
* stop rebuilding every grid panel when the item list changes ([#1096](https://github.com/grafana/profiles-drilldown/issues/1096)) ([72d6bcf](https://github.com/grafana/profiles-drilldown/commit/72d6bcfc1dc4469b9271cef78921b56ac5ed193d))


### 🧹 Chore

* **deps:** update golang docker tag to v1.26.5 ([#1082](https://github.com/grafana/profiles-drilldown/issues/1082)) ([7480059](https://github.com/grafana/profiles-drilldown/commit/748005985dd969b7b4f63b9dfba12d1b9fee5457))
* **faro:** duplicate rudderstack events as faro events and enhance instrumentation ([#1083](https://github.com/grafana/profiles-drilldown/issues/1083)) ([43711f4](https://github.com/grafana/profiles-drilldown/commit/43711f4a1fd06d27646432bd23fe8f36ac02dc55))
* move CONTRIBUTING to root of repo ([#1097](https://github.com/grafana/profiles-drilldown/issues/1097)) ([3711e23](https://github.com/grafana/profiles-drilldown/commit/3711e23c32c1aff185b780450bb3d996ee005ae8))
* remove profilesExemplars feature toggle ([#1090](https://github.com/grafana/profiles-drilldown/issues/1090)) ([57c5017](https://github.com/grafana/profiles-drilldown/commit/57c5017da40058aa504a1899d9dda826b0fa52e9))
* Update brace ([#1078](https://github.com/grafana/profiles-drilldown/issues/1078)) ([a3505f4](https://github.com/grafana/profiles-drilldown/commit/a3505f41e4ff12fed26dcdb90960855b744d4291))
* update dependencies ([#1087](https://github.com/grafana/profiles-drilldown/issues/1087)) ([55f40f2](https://github.com/grafana/profiles-drilldown/commit/55f40f252f0603c6dbc1c45b49207d20ef4d3910))

## [2.2.0](https://github.com/grafana/profiles-drilldown/compare/v2.1.1...v2.2.0) (2026-07-27)


### 🎉 Features

* Add filters to "All services" page ([#947](https://github.com/grafana/profiles-drilldown/issues/947)) ([de70e87](https://github.com/grafana/profiles-drilldown/commit/de70e8738f1b75f09d049147dd5aed89adc57efd))
* Profiles to Traces integration via span heatmap ([#934](https://github.com/grafana/profiles-drilldown/issues/934)) ([05fbcdd](https://github.com/grafana/profiles-drilldown/commit/05fbcdd7b3959c7d48615969d4da061a1ff6f1c7))
* remove data-driven annotations, add an extension point on the flame graph panel header ([#1051](https://github.com/grafana/profiles-drilldown/issues/1051)) ([b9197c0](https://github.com/grafana/profiles-drilldown/commit/b9197c08beea09d0835cd07c3fa642d2a1060430))


### 🐛 Bug Fixes

* avoid checking LLM plugin status when grafana-llm-app is not installed ([#1056](https://github.com/grafana/profiles-drilldown/issues/1056)) ([c1ef3d2](https://github.com/grafana/profiles-drilldown/commit/c1ef3d224614f7aa59fb7cf58e8400d4b8509772)), closes [#757](https://github.com/grafana/profiles-drilldown/issues/757)
* Avoid error exporting png from top table diff ([#1013](https://github.com/grafana/profiles-drilldown/issues/1013)) ([edfed94](https://github.com/grafana/profiles-drilldown/commit/edfed9489a6e125e0ae49478eef41ed99274ac64))
* **deps:** upgrade @grafana/* packages to 13.1.0 ([#1047](https://github.com/grafana/profiles-drilldown/issues/1047)) ([18b0bb2](https://github.com/grafana/profiles-drilldown/commit/18b0bb21c088b212f7272768db669effc764da95))
* **header:** use ButtonGroup for plugin header toolbar buttons ([#1065](https://github.com/grafana/profiles-drilldown/issues/1065)) ([95b50ce](https://github.com/grafana/profiles-drilldown/commit/95b50ce3948e1e3508673f6c00f4d404b9f73d66))
* remove span heatmap hover header ([#1062](https://github.com/grafana/profiles-drilldown/issues/1062)) ([b4b2651](https://github.com/grafana/profiles-drilldown/commit/b4b2651d4a9cd6c10df1b8df8feccfa07132b61e))
* scope span trace lookups to visible page ([#1061](https://github.com/grafana/profiles-drilldown/issues/1061)) ([4af682e](https://github.com/grafana/profiles-drilldown/commit/4af682ed9bf0784a76d257164e5d28e5c4d07006))
* show persistent settings-fetch error only on settings page ([#1057](https://github.com/grafana/profiles-drilldown/issues/1057)) ([5bed48c](https://github.com/grafana/profiles-drilldown/commit/5bed48c0c00116b3804629526aa52b37cf450887))
* time picker menu position ([#1068](https://github.com/grafana/profiles-drilldown/issues/1068)) ([3a39f0a](https://github.com/grafana/profiles-drilldown/commit/3a39f0a56240a90d7d1efbb37b28688a62cca789))


### 🧹 Chore

* **remote:** add remote provisioning for the llm app and traces ([#1054](https://github.com/grafana/profiles-drilldown/issues/1054)) ([e5d98d7](https://github.com/grafana/profiles-drilldown/commit/e5d98d706c46cf66fe4e5a9f98320194549b8723))

## [2.1.1](https://github.com/grafana/profiles-drilldown/compare/v2.1.0...v2.1.1) (2026-07-10)


### 🐛 Bug Fixes

* Fix empty profile type from URL sync and improve grid empty state ([#1046](https://github.com/grafana/profiles-drilldown/issues/1046)) ([f561976](https://github.com/grafana/profiles-drilldown/commit/f561976240224ced63f87ba0c1923498a035685d))
* include profile ID selector in function details query ([#1042](https://github.com/grafana/profiles-drilldown/issues/1042)) ([41e5efd](https://github.com/grafana/profiles-drilldown/commit/41e5efd686d6d17f5519a55028129f268e1f09c3))
* replace crypto.randomUUID with fallback for non-secure contexts ([#1019](https://github.com/grafana/profiles-drilldown/issues/1019)) ([a3f8304](https://github.com/grafana/profiles-drilldown/commit/a3f8304bb63c74de994575ca846d0f2649b46812)), closes [#1017](https://github.com/grafana/profiles-drilldown/issues/1017)
* **security/high/:** update pnpm to v11.8.0 [security] ([#1034](https://github.com/grafana/profiles-drilldown/issues/1034)) ([2626f08](https://github.com/grafana/profiles-drilldown/commit/2626f08d321bc5056676ac0f1da10c05f8b79f49))


### 📝 Documentation

* Add GenAI policy, contributor guide updates and issue templates ([#1041](https://github.com/grafana/profiles-drilldown/issues/1041)) ([7554854](https://github.com/grafana/profiles-drilldown/commit/755485460bf4a933bdf3ed035ca003d773190f46))


### 🧹 Chore

* Add give feedback link to plugin info menu and style updates ([#1043](https://github.com/grafana/profiles-drilldown/issues/1043)) ([a7eb27b](https://github.com/grafana/profiles-drilldown/commit/a7eb27b5d4fcf3bf13a96ade2f4dfcbad01de223))
* align i18next config with core Grafana ([#1033](https://github.com/grafana/profiles-drilldown/issues/1033)) ([1174a53](https://github.com/grafana/profiles-drilldown/commit/1174a53a1f49fabe5c39ff9a43c74fef66fb28f3))
* **deps:** update actions/checkout action to v6.0.3 ([#1039](https://github.com/grafana/profiles-drilldown/issues/1039)) ([2b016b1](https://github.com/grafana/profiles-drilldown/commit/2b016b1ea91b47b7b7babe16826d18d4c5322fc7))
* **deps:** update alpine:latest docker digest to 28bd5fe ([#1038](https://github.com/grafana/profiles-drilldown/issues/1038)) ([34ecfac](https://github.com/grafana/profiles-drilldown/commit/34ecfac224f3b9a5003bba4d4f2c16a536957829))
* **deps:** update dependency semver@6 to v7.8.5 ([#1040](https://github.com/grafana/profiles-drilldown/issues/1040)) ([841c3db](https://github.com/grafana/profiles-drilldown/commit/841c3db18fd5596c6ff9966cf67be7e2a299be06))

## [2.1.0](https://github.com/grafana/profiles-drilldown/compare/v2.0.7...v2.1.0) (2026-07-02)


### 🎉 Features

* add Knowledge Graph insights annotations to timeseries ([#886](https://github.com/grafana/profiles-drilldown/issues/886)) ([644600c](https://github.com/grafana/profiles-drilldown/commit/644600c9eb521a42d6841fb60cb2f83052fad33c))


### 🐛 Bug Fixes

* **deps:** bump dompurify override to ~3.4.11 for CVE remediation ([#1027](https://github.com/grafana/profiles-drilldown/issues/1027)) ([52ca002](https://github.com/grafana/profiles-drilldown/commit/52ca0026ed4f860ee5b4e27c39b4061364bf91cc))
* **deps:** update dependency protobufjs to v8.2.0 [security] ([#1001](https://github.com/grafana/profiles-drilldown/issues/1001)) ([e4ed126](https://github.com/grafana/profiles-drilldown/commit/e4ed126fcd48bbc457569184d0d9ce8858d00bcb))
* **security/unknown/samples/rideshare:** update module golang.org/x/sys to v0.44.0 [security] ([#1000](https://github.com/grafana/profiles-drilldown/issues/1000)) ([47d37b1](https://github.com/grafana/profiles-drilldown/commit/47d37b1b49c266d41f7d079fcfc73890cda6e850))


### 🤖 Continuous Integrations

* **release-please:** add release please ([#1024](https://github.com/grafana/profiles-drilldown/issues/1024)) ([61f2ed0](https://github.com/grafana/profiles-drilldown/commit/61f2ed05f88415153bc75a273b1a782abb00fff9))


### 🧹 Chore

* Add myself as a CODEOWNER ([#1015](https://github.com/grafana/profiles-drilldown/issues/1015)) ([8f7b5e6](https://github.com/grafana/profiles-drilldown/commit/8f7b5e68b8a20503e680ed293ed1ff40ac08fece))
* Better feature tracking for uploading profiles ([#983](https://github.com/grafana/profiles-drilldown/issues/983)) ([d6b2dda](https://github.com/grafana/profiles-drilldown/commit/d6b2ddadf5563e3c8631dbd61b2951cda11e5a35))
* **ci/cd:** update to 10.1.0 ([#1030](https://github.com/grafana/profiles-drilldown/issues/1030)) ([b1a5d19](https://github.com/grafana/profiles-drilldown/commit/b1a5d19453abf5956b0f1227cd36132b558f7898))
* **ci:** Update release workflows ([#1036](https://github.com/grafana/profiles-drilldown/issues/1036)) ([e858b91](https://github.com/grafana/profiles-drilldown/commit/e858b91e493413b7e853f5cdd603a9f6b10ef51a))
* **deps:** bump @openfeature/ofrep-web-provider from 0.3.6 to 0.4.1 ([#1011](https://github.com/grafana/profiles-drilldown/issues/1011)) ([f486480](https://github.com/grafana/profiles-drilldown/commit/f4864800f762400bb415b69e273f73134af5abcf))
* **deps:** update golang:1.26.3 docker digest to 2d6c802 ([#996](https://github.com/grafana/profiles-drilldown/issues/996)) ([4f07155](https://github.com/grafana/profiles-drilldown/commit/4f0715584268a3d4f218932c8b9cf333b1b9522e))
* Regenerate pyroscope API client ([#1025](https://github.com/grafana/profiles-drilldown/issues/1025)) ([c71c1e9](https://github.com/grafana/profiles-drilldown/commit/c71c1e9a4a918eb43f2c30be507ef9c6acac2461))
* Remove publish-technical-documentation workflows ([#1026](https://github.com/grafana/profiles-drilldown/issues/1026)) ([227ab2b](https://github.com/grafana/profiles-drilldown/commit/227ab2b6ec74a51b6eaa1a2d5832cfbc362d0287))
* Sanitize AiReply button link ([#1010](https://github.com/grafana/profiles-drilldown/issues/1010)) ([500489b](https://github.com/grafana/profiles-drilldown/commit/500489b1c6e4fa6b293632025829c3430ffa84a8))
* Surface backend error of creating a recording rule ([#1014](https://github.com/grafana/profiles-drilldown/issues/1014)) ([bb36a4c](https://github.com/grafana/profiles-drilldown/commit/bb36a4c20d2f06b563a5ce822f7eb678c4082964))
* Update LLM package ([#1032](https://github.com/grafana/profiles-drilldown/issues/1032)) ([667e618](https://github.com/grafana/profiles-drilldown/commit/667e618d43fe6b8349ff2eb90b9bc91a93b0a12b))
* Update packages ([#1020](https://github.com/grafana/profiles-drilldown/issues/1020)) ([f025c68](https://github.com/grafana/profiles-drilldown/commit/f025c682b122ed89567f8af31ddcbb9bc116d045))
* Workflows update ([#995](https://github.com/grafana/profiles-drilldown/issues/995)) ([f665d6d](https://github.com/grafana/profiles-drilldown/commit/f665d6d14ac3ccfcbfbfc9aa5595d4069950799a))

## 2.0.7

##### Chores

*  Update ci-cd-workflows (#987) (3de7b007)
*  update Saved queries texts (#1006) (500d8d73)
*  Harden package use and workspace environment (#984) (1ace8a94)
*  Fix translations (#986) (b58dea2d)
*  Use tabs instead of custom menu navigation (#974) (59c90d52)

##### New Features

*  Support add to dashboard (#970) (667d2a21)

##### Bug Fixes

*  update Crowdin workflows for get-vault-secrets breaking change (#1008) (86eabe59)
* **Recording Rules:**  Stop dropping profile type, service name, and function name on submit (#979) (c1d75858)

##### Other Changes

*  Download translations from Crowdin (#993) (5e02932b)
*  Download translations from Crowdin (#953) (ff04cc53)


## 2.0.6

##### Chores

* **deps:**
  *  bump protobufjs from 8.0.1 to 8.0.3 (#976) (9fdea055)
  *  update dependency protobufjs@^7.3.0 to v8 [security] (#972) (f4a4eea9)
  *  lock file maintenance (#969) (6b3f68a2)
  *  bump hono from 4.12.16 to 4.12.18 (#966) (b6edc18f)
  *  bump fast-uri from 3.1.1 to 3.1.2 (#967) (107f6c96)
  *  pin dependencies (#958) (8ac3c790)
  *  lock file maintenance (#926) (8ff0c056)
  *  update alpine:latest docker digest to 5b10f43 (#959) (4115a9ef)
  *  update golang:1.26 docker digest to b54cbf5 (#960) (7fcafe6c)
*  Update rideshare mod (#971) (f92c3079)
*  Update which feature flags are on by default (#965) (fd0ee099)
*  Fix loading translations before i18n available (#963) (87519cbf)
*  fix tests (#962) (1dc0d256)

##### New Features

* **time picker:**  add support for keyboard shortcuts (#936) (2965dbb3)

##### Bug Fixes

*  Download json (#975) (e7fdec78)

##### Other Changes

*  occured -> occurred in AI panel error message (#968) (dcb321f9)


## 2.0.5

##### Build System / Dependencies

*  migrate to pnpm (#949) (c26b6a84)

##### Chores

*  Update @grafana/flamegraph to 13.1.0-25141410377 (#957) (0464d5bf)
*  Use OpenFeature for all feature flags (#950) (75caf58d)
* **deps:**  bump postcss from 8.4.39 to 8.5.12 (#954) (bbe86aaf)
* **i18n:**  Expose all supported languages in plugin.json (#904) (37bdb2b6)

##### New Features

*  Use Grafana Assistant for Optimize Code button when available (#943) (284dc66f)

##### Bug Fixes

*  Revert changes to analyze flame graph button in SceneFlameGraph (#955) (c3d03d93)
*  consolidate CI/CD into single workflow to fix broken `workflow_run` chaining (#956) (218f43eb)

##### Other Changes

*  Download translations from Crowdin (#951) (4ff76d61)

##### Performance Improvements

* **i18n:**  prevent loading en-US translations at runtime (#938) (be0806e6)


## 2.0.4

##### Chores

* **deps:**
  *  update dependency dompurify to v3.4.0 [security] (#942) (0487f527)
  *  update dependency hono to v4.12.14 [security] (#941) (2c403fcf)

##### New Features

* **adhoc:**  add diff view with side-by-side and computed diff modes (#842) (d4461470)

##### Bug Fixes

* **deps:**
  *  patch CVEs via yarn resolutions (#948) (5624f69b)
  *  update dependency protobufjs to v8 [security] (#946) (04b77a2f)
  *  update module go.opentelemetry.io/otel/sdk to v1.43.0 [security] (#933) (63e52289)
* **samples:**  upgrade otel/sdk to v1.43.0 to address CVE (#940) (fbf87a0c)


## 2.0.3

##### Chores

* **ci:**  fix flaky tests (#939) (afd7acbe)


## 2.0.2

##### Chores

*  fix docker compose setup (#928) (30ba539f)
*  Warning for missing service names (#924) (0815b4ac)
*  Add more Renovate groups (#919) (b54139d1)
* **deps:**
  *  update dependency @hono/node-server to v1.19.13 [security] (#930) (693a90c3)
  *  update dependency hono to v4.12.12 [security] (#931) (ad2d87fc)
  *  update dependency lodash to v4.18.1 [security] (#921) (23fbc2b6)
  *  update dependency lodash to v4.18.1 [security] (#920) (5f0445c5)
  *  update dependency @types/node to v22.19.15 (#917) (d51853aa)
  *  update dependency @babel/core to v7.29.0 (#915) (e82681ea)
  *  update dependency tar to v7.5.13 (#913) (30192d02)
  *  update dependency semver to v7.7.4 (#912) (19d23060)
  *  update dependency nanoid to v5.1.7 (#911) (e349f466)
  *  update dependency i18next-cli to v1.51.4 (#910) (a2ed6c79)
  *  update dependency eslint-plugin-jsdoc to v62.8.1 (#907) (b99184b1)
  *  update dependency hono to v4.12.9 (#909) (5d3aa217)
  *  update dependency hono to v4.12.9 (#908) (3f0a50fe)
  *  update dependency eslint-plugin-jest to v29.15.1 (#906) (2348000f)
  *  update qdrant/qdrant docker digest to 9472857 (#896) (3fc040e6)
  *  update dependency esbuild to v0.27.4 (#905) (3999a247)
  *  update dependency @hono/node-server to v1.19.11 (#897) (6370f737)
  *  update dependency @types/lodash to v4.17.24 (#902) (87f9cca9)
  *  update dependency dompurify to v3.3.3 (#903) (0e90e176)
  *  update dependency @react-aria/utils to v3.33.1 (#900) (191768c9)
  *  update dependency @types/color to v3.0.7 (#901) (ed7b3a03)
  *  update grafana/grafana-enterprise:latest docker digest to 8b65309 (#895) (d04d330c)
  *  bump undici from 7.18.2 to 7.24.6 (#892) (162bfc66)
  *  update actions/checkout digest to 34e1148 (#847) (4bf70e2f)
  *  bump brace-expansion from 1.1.12 to 1.1.13 (#887) (c39dd9d7)
  *  update dependency serialize-javascript to v7.0.5 [security] (#888) (513129b6)
  *  pin dependencies (#846) (a851ae51)
  *  bump picomatch from 2.3.1 to 2.3.2 (#881) (a913aae0)
  *  update alpine:latest docker digest to 2510918 (#848) (f71200bb)
* **config:**  migrate config renovate.json (#922) (2f3a4847)
* **i18n:**
  *  add Crowdin GitHub Actions (#889) (694b0dd1)
  *  add ESLint rules and translate all user-facing strings (#885) (95a9b848)
  *  add @grafana/i18n infrastructure (#865) (b1a208a9)
* **eslint:**  migrate to ESLint 9 flat config (#876) (e7d6f2c7)

##### Documentation Changes

*  add exemplars documentation (#890) (591fe58b)
*  Increase weight of Profiles Drilldown to 200 (#923) (1f4fb7fc)

##### New Features

* **labels:**  support UTF-8 label names in label matchers (#925) (2521cffa)
* **ResolutionBoostExtensionPoint:**  pass datasourceUID to Adaptive Profiles extension (#880) (7a1b2f6f)
* **call-tree:**  enable the call tree visualization (#862) (7cfcb89c)

##### Bug Fixes

*  Sync time range sync between Diff page and the other pages (#784) (fce256a5)
* **deps:**  update grafana packages (#914) (53f1c84f)
* **ci:**  add permissions to PR validation workflow for Dependabot PRs (#883) (db27bf06)

##### Other Changes

*  Download translations from Crowdin (#918) (9578b975)
*  Download translations from Crowdin (#893) (5d3e1434)


## 2.0.1

##### Chores

*  Remove unused / update dependencies (#879) (0c0eb57a)
* **deps:**
  *  bump undici from 7.18.2 to 7.24.5 (#878) (91da6ba2)
  *  bump minimatch from 3.1.2 to 3.1.5 (#877) (03e3b581)
  *  update grafana/grafana-enterprise:latest docker digest to 8e8fc4c (#849) (fda61e94)
  *  update dependency flatted to v3.4.2 [security] (#874) (3ad985dc)


## 2.0.0

##### Chores

* **deps:**
  *  pin 11 transitive dependencies to fix 15 CVEs (#873) (a58f1e9b)
  *  pin minimatch@9.0.3 to 9.0.9 to fix CVE (#871) (4d79df99)
  *  bump undici from 7.18.2 to 7.24.4 (#867) (a7e5cfe1)
  *  update dependency tar to v7.5.11 [security] (#854) (b2a3b84c)
  *  bump hono from 4.11.9 to 4.12.0 (#834) (e3e92a16)
  *  bump ajv from 6.12.6 to 6.14.0 (#835) (6f272630)
*  React 19 upgrade (#858) (606a7c0a)
*  Fix codeowners file (#863) (d4d4e5a5)
*  add other drilldown teams as codeowners (#841) (8985e093)
* **cd:**  remove github-draft-release (#850) (00bbdcc8)

##### Documentation Changes

*  Updates for the latest release (#869) (8b135fc6)

##### New Features

*  Support Saved Queries (#868) (bb418724)
*  Add AGENTS.md and surrounding files (#870) (dffe1202)
*  highlight filtered exemplar on the timeseries for the flame gra… (#802) (7ce57937)
*  inspect a single exemplar's flamegraph (#796) (01dfcb1e)

##### Refactors

*  remove unused exemplar link helpers from data-transformations (#859) (9b44b15f)
*  rename exemplars var (#857) (23466603)


## 1.17.0

##### Chores

* **release:**
  *  publish github release (#825) (0c0d43ee)
  *  publish the release to github (6554320b)
* **deps:**
  *  update dependency tar to v7.5.8 [security] (#829) (e549788b)
  *  bump esbuild to 0.25.0 (#827) (ec99bdeb)
  *  update dependency @bufbuild/protoc-gen-es to v2.11.0 (#810) (55e4a194)
  *  update dependency terser-webpack-plugin to v5.3.16 (#807) (80596259)
  *  update dependency @types/lodash to v4.17.23 (#806) (46bf6def)
  *  update dependency webpack to v5.104.1 [security] (#813) (f3bab720)
*  Upgrade packages (#814) (9879f7b4)

##### Bug Fixes

* **deps:**  update grafana packages (#808) (807f4d8a)
*  use selected profile's version in function details panel (#801) (5b2a85ea)

##### Other Changes

* **release:**  publish the release to github" (00c520df)


## 1.16.0

##### New Features

*  switch cloud-home-app plugin proxy usage to own (#579) (689f4c82)


## 1.15.2

##### Chores

* **deps:**
  *  Upgrade dependencies (#804) (418c922d)
  *  Upgrade playwright to 1.58.0 (#805) (4a322241)


## 1.15.1


## 1.15.0

##### Chores

* **deps:**
  *  bump js-yaml from 3.14.1 to 3.14.2 (#783) (27db8c2c)
  *  bump form-data from 4.0.0 to 4.0.5 (#781) (d7a8550e)
  *  bump brace-expansion from 1.1.11 to 1.1.12 (#782) (3bb1e0fb)
  *  Update react-router-dom to 6.30.3 (#798) (648f0af6)
  *  bump @modelcontextprotocol/sdk from 1.24.3 to 1.25.2 (#789) (76fe5444)
  *  bump undici from 7.16.0 to 7.18.2 (#794) (b24186dc)
  *  bump body-parser from 2.2.0 to 2.2.2 (#788) (5d90c82f)
  *  bump qs from 6.14.0 to 6.14.1 (#786) (8a9e6002)
*  Remove investigations (#787) (188f8623)

##### Continuous Integration

*  update workflows (#792) (98baf273)

##### New Features

*  plot exemplars candidates in timeseries panel at the Flame graph view (#748) (9c87a512)

##### Bug Fixes

* **assistant:**  pass origin to openAssistant (#797) (d3a13ab7)
*  Handle missing location lines from profiles (#785) (9c7616c2)


## 1.14.2

##### Chores

*  update llm plugin (#780) (9e097bd5)


## 1.14.1

##### Bug Fixes

*  call /render for dot profiles only once Assistant is being opened (#778) (cbb2d764)
* **DiffFlameGraph:**  prevent API queries with zero time ranges (#777) (665d9f9b)


## 1.14.0

##### Chores

*  fix styling (#771) (14655e41)

##### New Features

* **DiffFlameGraph:**  Analyze Diff Flame Graph with Grafana Assistant (#752) (e18b2639)


## 1.13.0

##### Chores

* **deps:**
  *  update dependency @connectrpc/protoc-gen-connect-query to v2.2.0 (#764) (6241abc8)
  *  update dependency @babel/core to v7.28.5 (#762) (eead60db)
  *  update dependency @stylistic/eslint-plugin-ts to v2.13.0 (#765) (0c8acd3d)
  *  update dependency @bufbuild/protoc-gen-es to v2.10.1 (#763) (a3326219)
  *  update dependency dotenv to v16.6.1 (#766) (11df5159)
  *  update dependency glob to v10.5.0 [security] (#751) (5cc428be)
*  Upgrade Playwright to 1.57.0 (#760) (c094d592)
*  Update Grafana version used locally to match CI (#753) (8acf4daf)
*  remove unused deps (#742) (4066bdbc)
*  Add renovate rules (#746) (a06fa858)
*  update scenes (#733) (7d338e75)
* **config:**  migrate config renovate.json (#749) (608da61c)

##### New Features

*  Support source code integration for languages without file paths (#747) (a81f7109)
*  Embed Profiles Drilldown (#621) (b510bd19)

##### Bug Fixes

*  Do not force refresh ServiceName and ProfileMetric variables on time range change (#759) (4450a9ec)


## 1.12.0

##### Chores

* **deps:**
  *  update dependency @types/prismjs to v1.26.5 (#741) (fb16ca90)
  *  bump assistant-sdk version to 0.1.4 (6ecd1896)
  *  pin dependencies (#627) (74144bf5)
*  fix shared workflows versions (#736) (72747451)
*  Remove unused CI workflows (#634) (838fe138)
* **ci:**  Push PR branches to ops catalog (#735) (abd1e90f)

##### New Features

*  adaptive profiles boost button extension point (#626) (04964dc7)
* **Recording Rules:**  Show recording rule labels (#636) (e173a5d6)

##### Other Changes

* local (#744) (313db674)


## 1.11.0

##### Chores

*  fix version bump (#635) (844dfea2)
*  Update flamegraph package (#620) (6f31ac78)
*  Fix plugin.json formatting (#612) (f1f22f27)
*  Auto deploy to dev/ops (#618) (0b13153e)
* **annotations:**  Show annotations only on main timeline panels (#624) (c14295b4)
* **Recording Rules:**  Add disclaimer to metrics from profiles (#611) (4b306a5f)

##### Continuous Integration

*  Use version 2.x.x of plugin workflows (#622) (70ce3fa9)

##### New Features

* **Recording Rules:**  Allow using service_name as group by label (#617) (2825ee75)

##### Bug Fixes

* **Recording Rules:**  Do not pass empty matchers (#616) (602530fe)
* **GitHub:**  Keep GitHub Integration cookie between tabs (#609) (bb8ee3dd)


## 1.10.1

##### Chores

*  Update flamegraph package (#607) (12c37c7e)


## 1.10.0

##### Chores

*  Add missing target to plugin.json (#605) (3d7c76dc)
*  Update @grafana/faro-web-sdk to latest release (#603) (cb3615dc)
* **e2e:**  Upgrade Playwright to 1.55.1 (#604) (95940103)

##### Continuous Integration

*  Deploy automatically to ops (#600) (9632905b)

##### New Features

*  update extension point for grafana assistant, add vars and tests (#593) (50820a7a)

##### Bug Fixes

*  Update grafana/assistant (#597) (6a5758ac)


## 1.9.0

##### Chores

*  Use a specific version of Pyroscope for e2e tests (#587) (ab5a4543)

##### Continuous Integration

*  Add a workflow to publish a PR/branch (#578) (c690fc67)

##### New Features

* **Metrics From Profiles:**  Automatically prefix metric name (#592) (7404aba4)
*  Add rate calculation support and step synchronization (#548) (0538e0bc)
* **AI:**  Integrate with Grafana Assistant (#558) (0756b05a)

##### Bug Fixes

*  recording rules list to use rule id as row id (#591) (d07f2528)
*  use rule id as row id (4e261a87)


## 1.8.1


## 1.8.0

##### Chores

*  Upgrade playwright to 1.55 (#576) (601ee656)
*  Create plugin update (#564) (2ef28dc6)

##### Continuous Integration

*  Use shared action to create a changelog (32e56544)
*  Update release workflow (#573) (939c7b68)
*  Push build to ops (#570) (f42be894)
*  Use shared workflows for publishing (#565) (96855248)

# [1.7.0](https://github.com/grafana/profiles-drilldown/compare/v1.6.0...v1.7.0) (2025-07-31)


### Features

* Propagate the redirect_uri for GitHub logins ([#541](https://github.com/grafana/profiles-drilldown/issues/541)) ([d0ae06c](https://github.com/grafana/profiles-drilldown/commit/d0ae06c4a90cbfc5b6e1d1764b5ea196e3029f7d))
* **Recording Rules:** Pass function name to recording rules ([#543](https://github.com/grafana/profiles-drilldown/issues/543)) ([9000fd4](https://github.com/grafana/profiles-drilldown/commit/9000fd4d478dbac7adb59d7d07f421be570d58ec))
* Support for provisioned recording rules ([#549](https://github.com/grafana/profiles-drilldown/issues/549)) ([dc5fea3](https://github.com/grafana/profiles-drilldown/commit/dc5fea349e8198dce53f32e27ee124abc42bb9e7))



# [1.6.0](https://github.com/grafana/profiles-drilldown/compare/v1.5.0...v1.6.0) (2025-07-29)


### Features

* **GitHub:** Allow providing GitHub integration details manually ([#538](https://github.com/grafana/profiles-drilldown/issues/538)) ([70a61be](https://github.com/grafana/profiles-drilldown/commit/70a61be46936daa7b354d2671538bb2bc6c55c76))



# [1.5.0](https://github.com/grafana/profiles-drilldown/compare/v1.4.1...v1.5.0) (2025-07-10)


### Features

* **GitHub Integration:** Keep GitHub auth cookie within the same session if the data source doesn't change ([#535](https://github.com/grafana/profiles-drilldown/issues/535)) ([8a7b157](https://github.com/grafana/profiles-drilldown/commit/8a7b15791906ce4218a3a4ebf43969039b529727))
* **Metrics from Profiles:** Allow creating recording rules for all services ([#525](https://github.com/grafana/profiles-drilldown/issues/525)) ([837393b](https://github.com/grafana/profiles-drilldown/commit/837393b8d8ef41d50528722b03071c16ebc027fa))
* **metrics:** Show annotations ([#522](https://github.com/grafana/profiles-drilldown/issues/522)) ([5259b0b](https://github.com/grafana/profiles-drilldown/commit/5259b0b449bd37e18e1d406bc988a44f7f7dc709))



## [1.4.1](https://github.com/grafana/profiles-drilldown/compare/v1.4.0...v1.4.1) (2025-05-21)


### Features

* **GitHub Integration:** Add a github callback view ([#495](https://github.com/grafana/profiles-drilldown/issues/495)) ([012a0e6](https://github.com/grafana/profiles-drilldown/commit/012a0e6a775fd3af777ccae5c538e73bd83d4833))



# [1.4.0](https://github.com/grafana/profiles-drilldown/compare/v1.3.0...v1.4.0) (2025-05-15)


### Features

* Add extension point to add additional settings ([#478](https://github.com/grafana/profiles-drilldown/issues/478)) ([4ff758f](https://github.com/grafana/profiles-drilldown/commit/4ff758f4b2d0a458da647b663b2488140a0c0b63))



# [1.3.0](https://github.com/grafana/explore-profiles/compare/v1.2.3...v1.3.0) (2025-04-16)


### Bug Fixes

* Cascader options break when services have multiple levels with matching prefix ([#484](https://github.com/grafana/explore-profiles/issues/484)) ([2bb6034](https://github.com/grafana/explore-profiles/commit/2bb603464a329bec9b6da2c26ca0c30a2ef6f45e))
* **Settings:** Reload settings when data source changes ([#474](https://github.com/grafana/explore-profiles/issues/474)) ([23d814b](https://github.com/grafana/explore-profiles/commit/23d814be30fc8cf050024e556c132785d24a196c))


### Features

* **CI:** Append SHA to version number when releasing from main ([#455](https://github.com/grafana/explore-profiles/issues/455)) ([03e6158](https://github.com/grafana/explore-profiles/commit/03e6158377a87b6494ac39a9764296dd2de19a01))
* **Metrics:** Basic UI for experimental metrics from profiles ([#462](https://github.com/grafana/explore-profiles/issues/462)) ([1500a59](https://github.com/grafana/explore-profiles/commit/1500a59e6daeb097576449273e2dc3da47f8f311))



## [1.2.3](https://github.com/grafana/explore-profiles/compare/v1.2.2...v1.2.3) (2025-04-03)


### Bug Fixes

* Get suggestions for optimize code ([#480](https://github.com/grafana/explore-profiles/issues/480)) ([23674c3](https://github.com/grafana/explore-profiles/commit/23674c3eaf8adf5572a725bade08f0a53038e77b))



## [1.2.2](https://github.com/grafana/explore-profiles/compare/v1.2.1...v1.2.2) (2025-04-03)


### Bug Fixes

* revert "profiling insights" extension ([#447](https://github.com/grafana/explore-profiles/issues/447)) ([43b35dc](https://github.com/grafana/explore-profiles/commit/43b35dc8f929e922bb8d554b92c6a763581d3443))



## [1.2.1](https://github.com/grafana/explore-profiles/compare/v1.2.0...v1.2.1) (2025-04-02)


### Bug Fixes

* **FlameGraph:** Use entire file as context in "Optimize Code" prompt ([#459](https://github.com/grafana/explore-profiles/issues/459)) ([569c17c](https://github.com/grafana/explore-profiles/commit/569c17c41511167add7a7a4db3f90cbc88897d68))
* **llm:** Add extra context in AI prompt about other lines in a file ([#460](https://github.com/grafana/explore-profiles/issues/460)) ([004b7aa](https://github.com/grafana/explore-profiles/commit/004b7aa04a136b02f036c0e33a27d1b333cbbf93))


### Features

* "profiling insights" extension ([#447](https://github.com/grafana/explore-profiles/issues/447)) ([13ff552](https://github.com/grafana/explore-profiles/commit/13ff552083cc4555aa21e8401be1516a364b8271))



# [1.2.0](https://github.com/grafana/explore-profiles/compare/v1.1.0...v1.2.0) (2025-03-10)


### Features

* Add generated typed Pyroscope API client ([#410](https://github.com/grafana/explore-profiles/issues/410)) ([2e2b4e1](https://github.com/grafana/explore-profiles/commit/2e2b4e1d41fab1ed37029fff0073879f51fe932f))
* **FlameGraph:** Show the flame graph for a selected span ([#445](https://github.com/grafana/explore-profiles/issues/445)) ([2e036ee](https://github.com/grafana/explore-profiles/commit/2e036eeabc705e147560f13d8137821adf2585c5))



# [1.1.0](https://github.com/grafana/explore-profiles/compare/v1.0.0...v1.1.0) (2025-02-21)


### Bug Fixes

* **Routes:** Add redirection for non-supported paths ([#427](https://github.com/grafana/explore-profiles/issues/427)) ([edd56d3](https://github.com/grafana/explore-profiles/commit/edd56d34cb40dfc8bfbaba6788c6c04f46d571b2))


### Features

* **investigations:** adapt to changed plugin id ([#429](https://github.com/grafana/explore-profiles/issues/429)) ([7b41af9](https://github.com/grafana/explore-profiles/commit/7b41af95c9a938d05c008017b5546a5aab319531))
* Rename Explore Profiles to Grafana Profiles Drilldown ([#430](https://github.com/grafana/explore-profiles/issues/430)) ([e91ff90](https://github.com/grafana/explore-profiles/commit/e91ff90cf697070be37b2140d3318ea4135db7f4)), closes [#432](https://github.com/grafana/explore-profiles/issues/432)



# [1.0.0](https://github.com/grafana/explore-profiles/compare/v0.1.23...v1.0.0) (2025-02-14)


### Features

* **App:** Changes for GA ([#398](https://github.com/grafana/explore-profiles/issues/398)) ([71ed3f8](https://github.com/grafana/explore-profiles/commit/71ed3f8d312317474ffec674d056968f3fefad64))



## [0.1.23](https://github.com/grafana/explore-profiles/compare/v0.1.22...v0.1.23) (2025-02-14)


### Bug Fixes

* Remove lazy loading of page components ([#422](https://github.com/grafana/explore-profiles/issues/422)) ([45bc71e](https://github.com/grafana/explore-profiles/commit/45bc71e27ac8306d735c980b3436b61889f522d9))



## [0.1.22](https://github.com/grafana/explore-profiles/compare/v0.1.21...v0.1.22) (2025-02-13)


### Bug Fixes

* **FlameGraph:** Always render an error message when loading fails ([#407](https://github.com/grafana/explore-profiles/issues/407)) ([c531bf2](https://github.com/grafana/explore-profiles/commit/c531bf2296ac75da8938ce6af1ec1660dd6e7b73))


### Features

* **Tracking:** Add page view tracking ([#408](https://github.com/grafana/explore-profiles/issues/408)) ([cf5b786](https://github.com/grafana/explore-profiles/commit/cf5b786ada6e211af2385192b9f8059906f935f5))



## [0.1.21](https://github.com/grafana/explore-profiles/compare/v0.1.20...v0.1.21) (2025-02-12)


### Bug Fixes

* **Faro:** Narrow down frontend logging to plugin URL ([#395](https://github.com/grafana/explore-profiles/issues/395)) ([8d011ce](https://github.com/grafana/explore-profiles/commit/8d011cedab660fe23b0711b303ef3fe450b78614))



## [0.1.20](https://github.com/grafana/explore-profiles/compare/v0.1.19...v0.1.20) (2025-02-06)


### Bug Fixes

* **Filters:** Ensure filters are always cleared when changing the data source or the service ([#374](https://github.com/grafana/explore-profiles/issues/374)) ([1c7b6c3](https://github.com/grafana/explore-profiles/commit/1c7b6c3f537b9ff0bc9060bac5f0e2c240ba00c8))
* **FunctionDetailsPanel:** Fix start ellipsis for file names containing non-alpha chars ([#373](https://github.com/grafana/explore-profiles/issues/373)) ([f79a1b7](https://github.com/grafana/explore-profiles/commit/f79a1b7628d8dd0bfd478122a0296dd2a1c72948))
* **GitHubIntegration:** Handle function details for inlining ([#347](https://github.com/grafana/explore-profiles/issues/347)) ([5e28b3c](https://github.com/grafana/explore-profiles/commit/5e28b3c0e571f254915d08e0a166a66d33ff240b))
* **Grid:** Fix error message display ([#359](https://github.com/grafana/explore-profiles/issues/359)) ([1ca4ff2](https://github.com/grafana/explore-profiles/commit/1ca4ff2795cfa8118ec9e0d12dcad4b04d336534))
* **Settings:** Prevent warning to be displayed when no settings is returned by the Settings API ([#384](https://github.com/grafana/explore-profiles/issues/384)) ([cdce58a](https://github.com/grafana/explore-profiles/commit/cdce58a48bad24be1cf64ed81658bbcd0afca521))


### Features

* **AdHocView:** Remove Grafana menu item to the Ad Hoc view ([#385](https://github.com/grafana/explore-profiles/issues/385)) ([5c265fb](https://github.com/grafana/explore-profiles/commit/5c265fb4b5273083b6150aad46d32a6f44027fda))
* **LabelsView:** Add maxima visualizations ([#361](https://github.com/grafana/explore-profiles/issues/361)) ([25095c6](https://github.com/grafana/explore-profiles/commit/25095c6882d17ba6d88e7f5f861d5560e112a930))
* **LabelsView:** update main time series when a "group by" label is selected ([#341](https://github.com/grafana/explore-profiles/issues/341)) ([775b37d](https://github.com/grafana/explore-profiles/commit/775b37dc6ef9433b3f5674f56869a37a16892871))


### Performance Improvements

* **Series:** Limit the number of series request by breakdown charts ([#219](https://github.com/grafana/explore-profiles/issues/219)) ([8e1161d](https://github.com/grafana/explore-profiles/commit/8e1161df84283eecadc8aa9da55e46eb401a1e8c))



## [0.1.19](https://github.com/grafana/explore-profiles/compare/v0.1.18...v0.1.19) (2025-01-27)


### Bug Fixes

* **DiffFlameGraph:** Always disable time ranges sync before applying a preset ([#355](https://github.com/grafana/explore-profiles/issues/355)) ([272a98b](https://github.com/grafana/explore-profiles/commit/272a98bc13ffe7e93673c41ab1795b12ae2fbb3e))



## [0.1.18](https://github.com/grafana/explore-profiles/compare/v0.1.17...v0.1.18) (2025-01-23)


### Bug Fixes

* **DiffFlameGraphView:** Clear preset option when applying auto-select ([#313](https://github.com/grafana/explore-profiles/issues/313)) ([b0f4001](https://github.com/grafana/explore-profiles/commit/b0f400163378136b1d1a8485877e1fc596b1d222))
* **DiffFlameGraphView:** Preserve context after leaving/re-entering the view ([#319](https://github.com/grafana/explore-profiles/issues/319)) ([367ddab](https://github.com/grafana/explore-profiles/commit/367ddabe175c6a942b3ec2371d01a3013de1cccc))
* **Header:** Prevent crash if useChromeHeaderHeight is not available (for Grafana < 11.3) ([#312](https://github.com/grafana/explore-profiles/issues/312)) ([c638416](https://github.com/grafana/explore-profiles/commit/c6384162e1c3dc5f068dd814ad5431e23efb8537))
* **QueryRunners:** Prevent invalid queries to run ([#316](https://github.com/grafana/explore-profiles/issues/316)) ([5f5046c](https://github.com/grafana/explore-profiles/commit/5f5046cb82705c7ddeb2e80934becf3f8b887918))


### Features

* Add investigations support ([#301](https://github.com/grafana/explore-profiles/issues/301)) ([7f95852](https://github.com/grafana/explore-profiles/commit/7f958526d6af6d494a3f1095a89404d4fcacca10))
* Add query link extension ([#220](https://github.com/grafana/explore-profiles/issues/220)) ([62720ad](https://github.com/grafana/explore-profiles/commit/62720ad1cbd1346c772a521c133988d043851f55))
* **DiffView:** Time ranges sync ([#288](https://github.com/grafana/explore-profiles/issues/288)) ([45cea14](https://github.com/grafana/explore-profiles/commit/45cea14eef9fbde49f4474051a5833a1be623d2a))
* **FlameGraph:** Keep items focused when data changes ([#336](https://github.com/grafana/explore-profiles/issues/336)) ([d8ff887](https://github.com/grafana/explore-profiles/commit/d8ff887d0b9207c02a3a7563e845dab7df0b94d5))
* **GitHubIntegration:** Add info tooltip on connect button ([#328](https://github.com/grafana/explore-profiles/issues/328)) ([a929ddd](https://github.com/grafana/explore-profiles/commit/a929ddd56ea983ad5b5210c3e276afc778d7cdba))
* **Timeseries:** Add open in Explore menu item ([#300](https://github.com/grafana/explore-profiles/issues/300)) ([a9b0891](https://github.com/grafana/explore-profiles/commit/a9b0891aa2bc3666b57b2b9ab06e1b704dde8e85))
* Upgrade Grafana to v11.3.0 ([#287](https://github.com/grafana/explore-profiles/issues/287)) ([595a1cc](https://github.com/grafana/explore-profiles/commit/595a1cca4a83f84341c258f823a2cd2b61659268))


### Performance Improvements

* Lazy load page components ([#324](https://github.com/grafana/explore-profiles/issues/324)) ([c0ffd33](https://github.com/grafana/explore-profiles/commit/c0ffd33b3f1c2b6d9ae960429ebf23d1436bdde3))


### Reverts

* Revert "refactor(*): Lazy load page components (#322)" (#323) ([362e02b](https://github.com/grafana/explore-profiles/commit/362e02b6a8356dd9366259a56d4d1c56b3b522a0)), closes [#322](https://github.com/grafana/explore-profiles/issues/322) [#323](https://github.com/grafana/explore-profiles/issues/323)



## [0.1.17](https://github.com/grafana/explore-profiles/compare/v0.1.16...v0.1.17) (2024-11-19)


### Bug Fixes

* **ServiceDropdown:** Retrieve last used service name only if it's not provided in the URL ([#284](https://github.com/grafana/explore-profiles/issues/284)) ([28ca16e](https://github.com/grafana/explore-profiles/commit/28ca16ea5cd1340019278756fd9cfa7f583df268))



## [0.1.16](https://github.com/grafana/explore-profiles/compare/v0.1.15...v0.1.16) (2024-11-14)


### Bug Fixes

* **QueryBuilder:** Prevent invalid filters to be used after parsing ([#276](https://github.com/grafana/explore-profiles/issues/276)) ([e6cac6e](https://github.com/grafana/explore-profiles/commit/e6cac6ed097a1ce0609d4fc83400de2303f33fec))
* **Tracking:** Ensure select action type is tracked ([#278](https://github.com/grafana/explore-profiles/issues/278)) ([9527644](https://github.com/grafana/explore-profiles/commit/952764487d676408ce05b741902ada9ad3571b8b))
* **Tracking:** Use custom reporter ([#277](https://github.com/grafana/explore-profiles/issues/277)) ([dfbb3a6](https://github.com/grafana/explore-profiles/commit/dfbb3a6a6c8f177d9ecf66a52fbb2b7794ea686f))


### Features

* **Export:** Clarify that export to flamegraph.com option will create a public URL ([#275](https://github.com/grafana/explore-profiles/issues/275)) ([c5a0962](https://github.com/grafana/explore-profiles/commit/c5a0962bdf4cd19d9427515384e9c106b9dedd07))
* **Export:** Disable export to flame graph.com ([#280](https://github.com/grafana/explore-profiles/issues/280)) ([e631055](https://github.com/grafana/explore-profiles/commit/e63105522393c096feceb3f0a66cd9e1e0934a56))



## [0.1.15](https://github.com/grafana/explore-profiles/compare/v0.1.14...v0.1.15) (2024-11-05)


### Bug Fixes

* **DiffView:** Clicking on "Auto-select" selects a 25% range ([#254](https://github.com/grafana/explore-profiles/issues/254)) ([9b3dd8a](https://github.com/grafana/explore-profiles/commit/9b3dd8a16a961d319fe4e7190f772527d0d9e5e0))
* **DiffView:** Disable AI button when no selections ([#258](https://github.com/grafana/explore-profiles/issues/258)) ([58e89cb](https://github.com/grafana/explore-profiles/commit/58e89cb20d7bbfe08e5cfcabc00bb8dd6030f581))
* **DiffView:** Ensure ranges are initialized when landing ([#233](https://github.com/grafana/explore-profiles/issues/233)) ([4f95549](https://github.com/grafana/explore-profiles/commit/4f955491f9bf795aedb9d6aa79e7ba08d5379e7b))
* **DiffView:** Fix headers wrap ([#259](https://github.com/grafana/explore-profiles/issues/259)) ([6ada58a](https://github.com/grafana/explore-profiles/commit/6ada58afe7f981ed71ec68e9481e29a95633e13a))
* **DiffView:** Fix incorrect preset label ([#257](https://github.com/grafana/explore-profiles/issues/257)) ([a738694](https://github.com/grafana/explore-profiles/commit/a738694e5f6618f0efce7654852fb1189a2c920d))
* **ExplorationSelector:** Fix background color ([#255](https://github.com/grafana/explore-profiles/issues/255)) ([46db256](https://github.com/grafana/explore-profiles/commit/46db25677c0f54150f55a8fdfaa051d9ace33ab3))
* **FunctionDetails:** Correctly render blank lines ([ec3ed5c](https://github.com/grafana/explore-profiles/commit/ec3ed5c915d317c9ae6c15c4f1c00dc12cfaac39))
* **GitHubIntegration:** Fix "Learn more" href ([#245](https://github.com/grafana/explore-profiles/issues/245)) ([1848159](https://github.com/grafana/explore-profiles/commit/184815953a3fb5c20b6586df59b89b5b948695b6))
* **LabelValuesGrid:** decrease column size to accommodate small screen resolutions ([#235](https://github.com/grafana/explore-profiles/issues/235)) ([f62b17a](https://github.com/grafana/explore-profiles/commit/f62b17a32f91fe97cc133f93204ae365837fb1e3))
* **OnboardingModal:** Change Grafana Agent to Grafana Alloy ([#256](https://github.com/grafana/explore-profiles/issues/256)) ([27453ed](https://github.com/grafana/explore-profiles/commit/27453edef4051ea2ae4399b9502f1ed2aa18081c))
* **SettingsView:** Fix back button after modifying the max nodes setting ([#234](https://github.com/grafana/explore-profiles/issues/234)) ([673b44c](https://github.com/grafana/explore-profiles/commit/673b44cffe5e00378780da40d4d8c94d8289e171))
* **ShareableUrl:** Fix when the default time range is selected ([#244](https://github.com/grafana/explore-profiles/issues/244)) ([ae6ddeb](https://github.com/grafana/explore-profiles/commit/ae6ddeb842066fb8513a1ebd4c50133bf8a41b69))
* Small UI fixes ([#248](https://github.com/grafana/explore-profiles/issues/248)) ([ee881fa](https://github.com/grafana/explore-profiles/commit/ee881fa06929fa317299a0e24b6eca4e228cb571))
* **Timeseries:** Persist scale when data changes ([#251](https://github.com/grafana/explore-profiles/issues/251)) ([8cb6ced](https://github.com/grafana/explore-profiles/commit/8cb6ced4272a826f2a63e921eda2f62ee4d1a18d))


### Features

* **AppHeader:** Revamp header ([#230](https://github.com/grafana/explore-profiles/issues/230)) ([f482d7b](https://github.com/grafana/explore-profiles/commit/f482d7b2e4c77c7e88061e7198a85e5fd778c47b))
* **DiffFlameGraph:** Add "how to" infos ([#228](https://github.com/grafana/explore-profiles/issues/228)) ([494b659](https://github.com/grafana/explore-profiles/commit/494b659eb983231b9971429009b9185c7e5203a3))
* **DiffView:** Add CTAs and comparison presets ([#231](https://github.com/grafana/explore-profiles/issues/231)) ([e8bbf2e](https://github.com/grafana/explore-profiles/commit/e8bbf2e9e40dfc6e0eec6e4e8aa9ec35917d04d1))
* **LabelsView:** Include/exclude panel actions ([#210](https://github.com/grafana/explore-profiles/issues/210)) ([2c2d5f5](https://github.com/grafana/explore-profiles/commit/2c2d5f59b54ae2e49cd67dc5c5ea265b21e9a53f))
* **TimeSeries:** Add menu with scale options ([#249](https://github.com/grafana/explore-profiles/issues/249)) ([06b71d1](https://github.com/grafana/explore-profiles/commit/06b71d16190f9fd081c6f980ca580f58b1a1d2c5))



## [0.1.14](https://github.com/grafana/explore-profiles/compare/v0.1.13...v0.1.14) (2024-10-17)


### Bug Fixes

* **Faro:** Filter out events not related to the app ([#225](https://github.com/grafana/explore-profiles/issues/225)) ([57a7c58](https://github.com/grafana/explore-profiles/commit/57a7c581988d8418baa58ec872780e98f4703733))
* **Header:** Fix sticky header position in Grafana v11.3+ ([#218](https://github.com/grafana/explore-profiles/issues/218)) ([a4f226f](https://github.com/grafana/explore-profiles/commit/a4f226ff44c8b991efe1ab64cf4a4557f2dba903))


### Features

* **ServiceNameVariable:** Persist last service selected in localStorage ([#222](https://github.com/grafana/explore-profiles/issues/222)) ([3917660](https://github.com/grafana/explore-profiles/commit/39176600a4c260aa33499635954df5174fc6a54a))



## [0.1.13](https://github.com/grafana/explore-profiles/compare/v0.1.12...v0.1.13) (2024-10-08)


### Features

* **UI:** Another batch of minor improvements ([#213](https://github.com/grafana/explore-profiles/issues/213)) ([8419560](https://github.com/grafana/explore-profiles/commit/8419560160ce99824eaa3f56889a50a9a01b5919))



## [0.1.12](https://github.com/grafana/explore-profiles/compare/v0.1.11...v0.1.12) (2024-10-04)


### Bug Fixes

* **Code:** do not show Optimize Code button when no code is available ([#208](https://github.com/grafana/explore-profiles/issues/208)) ([6af234d](https://github.com/grafana/explore-profiles/commit/6af234d6a4fec65a1c51adf9439cd28802462173))
* **Filters:** ensure "is empty" filter is synced with URL ([#205](https://github.com/grafana/explore-profiles/issues/205)) ([8fc8fc4](https://github.com/grafana/explore-profiles/commit/8fc8fc4fdc31860cd1d1def3ca7f603ffe5b10fe))
* **QueryBuilder:** Filters with regex values can be edited in place ([#207](https://github.com/grafana/explore-profiles/issues/207)) ([75de5e2](https://github.com/grafana/explore-profiles/commit/75de5e291cb46930e18e7f41fef6166ec69fa341))


### Features

* Minor improvements ([#211](https://github.com/grafana/explore-profiles/issues/211)) ([0486f33](https://github.com/grafana/explore-profiles/commit/0486f338404915525f53ae26b9723ac0455e216a))
* **QueryBuilder:** Enable "in"/"not in" operators ([#122](https://github.com/grafana/explore-profiles/issues/122)) ([9574828](https://github.com/grafana/explore-profiles/commit/9574828fead1168e0d143de49357f5997c5eaf5f))
* **StatsPanel:** Add title on hover value + vertical border to separate compare actions ([#212](https://github.com/grafana/explore-profiles/issues/212)) ([71a29e5](https://github.com/grafana/explore-profiles/commit/71a29e506596d3f9207cab2ae9f658ff079c088e))



## [0.1.11](https://github.com/grafana/explore-profiles/compare/v0.1.10...v0.1.11) (2024-09-30)


### Features

* Minor UI improvements (timeseries point size, plugin info tooltip) ([#194](https://github.com/grafana/explore-profiles/issues/194)) ([621982a](https://github.com/grafana/explore-profiles/commit/621982a990c320594c6764e1ce035aacde652ac8))
* **QuickFilter:** Add results count ([#193](https://github.com/grafana/explore-profiles/issues/193)) ([dc4012d](https://github.com/grafana/explore-profiles/commit/dc4012d39aed84561fb7d14726e426aad95544b6))



## [0.1.10](https://github.com/grafana/explore-profiles/compare/v0.1.9...v0.1.10) (2024-09-25)



## [0.1.9](https://github.com/grafana/explore-profiles/compare/v0.1.8...v0.1.9) (2024-09-17)


### Bug Fixes

* **DiffFlameGraph:** Remove non-working pprof export ([#169](https://github.com/grafana/explore-profiles/issues/169)) ([662cd48](https://github.com/grafana/explore-profiles/commit/662cd488ae7a41e4843ca66694743d4777ac1230))
* **ExplainFlameGraph:** Add tooltip when the LLM plugin is not installed ([#163](https://github.com/grafana/explore-profiles/issues/163)) ([d395391](https://github.com/grafana/explore-profiles/commit/d3953913be2b072ddac8413fd9341a43dc4f865e))
* **Faro:** Fix Faro SDK config ([#174](https://github.com/grafana/explore-profiles/issues/174)) ([3ed6362](https://github.com/grafana/explore-profiles/commit/3ed636207927c0423cbca8c40444ba57cd6885b2))
* Fix useUrlSearchParams ([#171](https://github.com/grafana/explore-profiles/issues/171)) ([179b060](https://github.com/grafana/explore-profiles/commit/179b0608d5d99fa5370dcee52c8431259de1da1f))
* **LabelsDataSource:** Limit the maximum number of concurrent requests to fetch label values ([#165](https://github.com/grafana/explore-profiles/issues/165)) ([cb8149c](https://github.com/grafana/explore-profiles/commit/cb8149c36f4f40502b62d1f4ed96c46ea10a2c65))


### Features

* Add give feeback button and preview badge ([#167](https://github.com/grafana/explore-profiles/issues/167)) ([a23fa61](https://github.com/grafana/explore-profiles/commit/a23fa61b8982b0c8877a0b70ecab26747d1e4fa0))
* **AppHeader:** Add Settings button ([#172](https://github.com/grafana/explore-profiles/issues/172)) ([9d7fb6b](https://github.com/grafana/explore-profiles/commit/9d7fb6b08b9bea0cfebe6a74c883d8ff92cc9ad9))
* Remove legacy comparison views code ([#143](https://github.com/grafana/explore-profiles/issues/143)) ([816363f](https://github.com/grafana/explore-profiles/commit/816363faea2dcbf10789bb68a50b3e85947fc2a4))
* Upgrade Grafana to v11.2.0 ([#173](https://github.com/grafana/explore-profiles/issues/173)) ([15680e6](https://github.com/grafana/explore-profiles/commit/15680e6b810f7771e9a874b0cacd6d093403354d))



## [0.1.8](https://github.com/grafana/explore-profiles/compare/v0.1.6...v0.1.8) (2024-09-11)


### Bug Fixes

* **Labels:** Fix error with bar gauges viz and new Grafana version ([#159](https://github.com/grafana/explore-profiles/issues/159)) ([b527961](https://github.com/grafana/explore-profiles/commit/b52796103af9db785d681fdac22bf6d751a7f734))


### Features

* Add histogram visualizations ([#141](https://github.com/grafana/explore-profiles/issues/141)) ([2265be7](https://github.com/grafana/explore-profiles/commit/2265be70ea67cfdc44aad33e1a1f7951076db815))
* create new browser history entry on some user actions  ([#128](https://github.com/grafana/explore-profiles/issues/128)) ([5439ab3](https://github.com/grafana/explore-profiles/commit/5439ab32f0e4a21f3affbe6bfbe12da7cacd12b1))
* **DiffFlameGraph:** Add flame graph range in timeseries legend ([#140](https://github.com/grafana/explore-profiles/issues/140)) ([8729c31](https://github.com/grafana/explore-profiles/commit/8729c31dddf383d2d6ca4c2178397045c31d9654))
* **GitHubIntegration:** Migrate GitHub integration to Scenes ([#142](https://github.com/grafana/explore-profiles/issues/142)) ([0386bbc](https://github.com/grafana/explore-profiles/commit/0386bbc369538763c69fce1cc07a45fb82619beb))
* support submodules for GitHub Integration ([#147](https://github.com/grafana/explore-profiles/issues/147)) ([52ecea8](https://github.com/grafana/explore-profiles/commit/52ecea89b5a436b3dc03ff352127f55ea315e037))



## [0.1.7](https://github.com/grafana/explore-profiles/compare/v0.1.6...v0.1.7) (2024-08-29)


### Features

* Add histogram visualizations ([#141](https://github.com/grafana/explore-profiles/issues/141)) ([2265be7](https://github.com/grafana/explore-profiles/commit/2265be70ea67cfdc44aad33e1a1f7951076db815))
* create new browser history entry on some user actions  ([#128](https://github.com/grafana/explore-profiles/issues/128)) ([5439ab3](https://github.com/grafana/explore-profiles/commit/5439ab32f0e4a21f3affbe6bfbe12da7cacd12b1))
* **DiffFlameGraph:** Add flame graph range in timeseries legend ([#140](https://github.com/grafana/explore-profiles/issues/140)) ([8729c31](https://github.com/grafana/explore-profiles/commit/8729c31dddf383d2d6ca4c2178397045c31d9654))
* **GitHubIntegration:** Migrate GitHub integration to Scenes ([#142](https://github.com/grafana/explore-profiles/issues/142)) ([0386bbc](https://github.com/grafana/explore-profiles/commit/0386bbc369538763c69fce1cc07a45fb82619beb))



## [0.1.6](https://github.com/grafana/explore-profiles/compare/v0.1.5...v0.1.6) (2024-08-27)


### Bug Fixes

* **Ci:** Fix docker compose commands ([#111](https://github.com/grafana/explore-profiles/issues/111)) ([4ee541a](https://github.com/grafana/explore-profiles/commit/4ee541acbe822d92abfc9344eda4611600b1476e))
* **DiffFlameGraph:** Fix the "Explain Flame Graph" (AI) feature ([#129](https://github.com/grafana/explore-profiles/issues/129)) ([a40c02b](https://github.com/grafana/explore-profiles/commit/a40c02b7c37ac309d878689c5929ef770900d6f5))
* **Favorites:** Render "No results" when there are no favorites ([#101](https://github.com/grafana/explore-profiles/issues/101)) ([426469d](https://github.com/grafana/explore-profiles/commit/426469d239b9ac86ad7e6fe4a21385836926a264))
* **Labels:** Fix "Discarded by user" error in the UI ([#110](https://github.com/grafana/explore-profiles/issues/110)) ([2e9baab](https://github.com/grafana/explore-profiles/commit/2e9baab391168022f4de7bf3933e8ba4baac95df))
* **SceneLabelValuePanel:** Fix border color when baseline/comparison is selected ([#123](https://github.com/grafana/explore-profiles/issues/123)) ([5b4058a](https://github.com/grafana/explore-profiles/commit/5b4058a90ac6f713d50c9686813f273233dc4a39))
* **ScenesProfileExplorer:** Make labels more responsive on smaller screens ([10c97dc](https://github.com/grafana/explore-profiles/commit/10c97dc69714a6a0f97bbaa086dd7263e8e72950))


### Features

* **CompareView:** Implement new Comparison view with Scenes ([#119](https://github.com/grafana/explore-profiles/issues/119)) ([127d6c3](https://github.com/grafana/explore-profiles/commit/127d6c3f952d1e679bcb29c6e2d62ca9d1eed51f))
* **FlameGraph:** Add missing export menu ([#132](https://github.com/grafana/explore-profiles/issues/132)) ([f57b0ca](https://github.com/grafana/explore-profiles/commit/f57b0ca5329b0b2a7e58f7387391299475ddc952))
* **Labels:** Improve comparison flow ([#117](https://github.com/grafana/explore-profiles/issues/117)) ([31d0632](https://github.com/grafana/explore-profiles/commit/31d06326fa9e82a906635ac371a9e206cfa2bb54))
* **Timeseries:** Add total resource consumption in legend ([#108](https://github.com/grafana/explore-profiles/issues/108)) ([1fbb2df](https://github.com/grafana/explore-profiles/commit/1fbb2dfbc1d0a5d837afa74c4783171aded0258a))



## [0.1.5](https://github.com/grafana/explore-profiles/compare/v0.1.4...v0.1.5) (2024-07-29)


### Features

* **Labels:** Various UI/UX improvements ([#93](https://github.com/grafana/explore-profiles/issues/93)) ([bddad3c](https://github.com/grafana/explore-profiles/commit/bddad3cf21e6e1459eed03167c8c6f6d24e802d4))
* Revamp exploration type selector ([#94](https://github.com/grafana/explore-profiles/issues/94)) ([60dab67](https://github.com/grafana/explore-profiles/commit/60dab67af27f7ec72a3e9de11885f901937c23ed))



## [0.1.4](https://github.com/grafana/explore-profiles/compare/v0.1.3...v0.1.4) (2024-07-25)


### Bug Fixes

* **Onboarding:** Handle gracefully when there's no data source configured ([#76](https://github.com/grafana/explore-profiles/issues/76)) ([4c18444](https://github.com/grafana/explore-profiles/commit/4c1844498d8b3bde4bb5b30ac889419b7462fb8b))
* **PanelTitle:** Remove series count when only 1 serie ([#78](https://github.com/grafana/explore-profiles/issues/78)) ([8422e6d](https://github.com/grafana/explore-profiles/commit/8422e6d2b2d8e21d0178ed20599ce13e16194da5))
* **SceneByVariableRepeaterGrid:** Prevent extra renders ([#86](https://github.com/grafana/explore-profiles/issues/86)) ([bf14755](https://github.com/grafana/explore-profiles/commit/bf1475580f68beec434287283d079d0fed250cad))


### Features

* Avoid no data panels ([#80](https://github.com/grafana/explore-profiles/issues/80)) ([72120b7](https://github.com/grafana/explore-profiles/commit/72120b7c4020017ed0479131ef0ddb7b5620d517))
* **LabelsExploration:** Introduce bar gauge visualisations ([#72](https://github.com/grafana/explore-profiles/issues/72)) ([7b1b19a](https://github.com/grafana/explore-profiles/commit/7b1b19a81e0ca6825bae9f2b06795199f4c9d209))
* **SceneLabelValuesTimeseries:** Colors and legends are preserved on expanded timeseries ([#85](https://github.com/grafana/explore-profiles/issues/85)) ([6980299](https://github.com/grafana/explore-profiles/commit/69802997b1a5fc72938bb0eaaf27e99076980f7a))
* Various enhancements after first UX interview ([#81](https://github.com/grafana/explore-profiles/issues/81)) ([2cdfcbe](https://github.com/grafana/explore-profiles/commit/2cdfcbecae5b1bd74310a3cbd8a115bc1e166525))



## [0.1.3](https://github.com/grafana/explore-profiles/compare/v0.1.2...v0.1.3) (2024-07-19)


### Bug Fixes

* **Header:** Switch the exploration type radio button group to a select on narrow screens ([#70](https://github.com/grafana/explore-profiles/issues/70)) ([55f420a](https://github.com/grafana/explore-profiles/commit/55f420a532ee8f2d6d955112d2dd4665df18cf67))



## [0.1.2](https://github.com/grafana/explore-profiles/compare/v0.0.46-explore-profiles-beta-35...v0.1.2) (2024-07-17)


### Bug Fixes

* **CompareAction:** Add missing data source query parameter to compare URL ([#58](https://github.com/grafana/explore-profiles/issues/58)) ([b1213e1](https://github.com/grafana/explore-profiles/commit/b1213e13aad71f11bbd8473571b4d9ae37924b8f))
* **FunctionDetails:** Get timeline state from Flame Graph component ([#25](https://github.com/grafana/explore-profiles/issues/25)) ([64ed0e6](https://github.com/grafana/explore-profiles/commit/64ed0e68a22445111b1d1ec02dff9b2fd8daecaa))
* **GitHub Integration:** Correctly extract the start/end timestamps from time picker ([#15](https://github.com/grafana/explore-profiles/issues/15)) ([fe8d807](https://github.com/grafana/explore-profiles/commit/fe8d807a83fce1b3b3b1eeb39d980af0312548bb))
* **SceneAllLabelValuesTableState:** Fix color contrast in light mode ([#26](https://github.com/grafana/explore-profiles/issues/26)) ([1bd268f](https://github.com/grafana/explore-profiles/commit/1bd268fd2bf2236ed9b6853e6d48a17933107bf5))
* **SceneByVariableRepeaterGrid:** Set timeseries min to 0 ([#31](https://github.com/grafana/explore-profiles/issues/31)) ([0e3a17d](https://github.com/grafana/explore-profiles/commit/0e3a17df3363cb2b61bab85039522e44eb766c61))
* **SceneFlameGraph:** Fix runtime error ([#45](https://github.com/grafana/explore-profiles/issues/45)) ([6227f2d](https://github.com/grafana/explore-profiles/commit/6227f2dcb1d705259fb1ad8ae9f144eb17cd80b1))
* **SceneFlameGraph:** Respect maxNodes when set in the URL ([#29](https://github.com/grafana/explore-profiles/issues/29)) ([85dd5b7](https://github.com/grafana/explore-profiles/commit/85dd5b79833f1737c0cf5505b743e50e256a20dc))


### Features

* **Analytics:** Track Explore Profiles actions ([#64](https://github.com/grafana/explore-profiles/issues/64)) ([ec58f57](https://github.com/grafana/explore-profiles/commit/ec58f5771c6ff59fcbd444ac62c2e55dd1bda202))
* **DataSource:** Store selected data source in local storage ([#60](https://github.com/grafana/explore-profiles/issues/60)) ([9f7ede1](https://github.com/grafana/explore-profiles/commit/9f7ede188279010502f2bcef02b2caba94b5064f))
* **SingleView:** Remove page ([#20](https://github.com/grafana/explore-profiles/issues/20)) ([16da70d](https://github.com/grafana/explore-profiles/commit/16da70d7f424c17982a8ca1ceab24a2589121007))
* Update plugin metadata to auto enable ([#65](https://github.com/grafana/explore-profiles/issues/65)) ([3afd1cd](https://github.com/grafana/explore-profiles/commit/3afd1cd6cbdaf93583978ecab80af8a620e313ef))
* Various minor improvements ([#46](https://github.com/grafana/explore-profiles/issues/46)) ([877b009](https://github.com/grafana/explore-profiles/commit/877b0094ffd21794b5742db6fbfb32ebd5868a4c))



# [0.1.0](https://github.com/grafana/explore-profiles/compare/v0.0.46-explore-profiles-beta-35...v0.1.0) (2024-07-15)

Explore Profiles is now available in its initial public release. It is designed to offer a seamless, query-less experience for browsing and analyzing profiling data.

Key features include:

- **Native integration with Pyroscope**: Seamlessly integrates with Pyroscope backend to provide detailed performance profiling and analysis.
- **Query-Less Browsing**: Navigate profiling data without the need for complex queries.
- **AI-Powered flame graph analysis**: uses a large-language model (LLM) to assist with flame graph data interpretation so you can identify bottlenecks, and get to the bottom of performance issues faster.

### Bug Fixes

- **GitHub Integration:** Correctly extract the start/end timestamps from time picker ([#15](https://github.com/grafana/explore-profiles/issues/15)) ([fe8d807](https://github.com/grafana/explore-profiles/commit/fe8d807a83fce1b3b3b1eeb39d980af0312548bb))
- **SceneAllLabelValuesTableState:** Fix color contrast in light mode ([#26](https://github.com/grafana/explore-profiles/issues/26)) ([1bd268f](https://github.com/grafana/explore-profiles/commit/1bd268fd2bf2236ed9b6853e6d48a17933107bf5))
- **SceneByVariableRepeaterGrid:** Set timeseries min to 0 ([#31](https://github.com/grafana/explore-profiles/issues/31)) ([0e3a17d](https://github.com/grafana/explore-profiles/commit/0e3a17df3363cb2b61bab85039522e44eb766c61))
- **SceneFlameGraph:** Fix runtime error ([#45](https://github.com/grafana/explore-profiles/issues/45)) ([6227f2d](https://github.com/grafana/explore-profiles/commit/6227f2dcb1d705259fb1ad8ae9f144eb17cd80b1))
- **SceneFlameGraph:** Respect maxNodes when set in the URL ([#29](https://github.com/grafana/explore-profiles/issues/29)) ([85dd5b7](https://github.com/grafana/explore-profiles/commit/85dd5b79833f1737c0cf5505b743e50e256a20dc))

### Features

- Bump version to 0.1.0 ([3e480f9](https://github.com/grafana/explore-profiles/commit/3e480f90c06cba6d9ac3558026a1c892963db4c6))
- **SingleView:** Remove page ([#20](https://github.com/grafana/explore-profiles/issues/20)) ([16da70d](https://github.com/grafana/explore-profiles/commit/16da70d7f424c17982a8ca1ceab24a2589121007))
- Various minor improvements ([#46](https://github.com/grafana/explore-profiles/issues/46)) ([877b009](https://github.com/grafana/explore-profiles/commit/877b0094ffd21794b5742db6fbfb32ebd5868a4c))
