# Changelog

## [2.2.0](https://github.com/grafana/traces-drilldown/compare/v2.1.0...v2.2.0) (2026-08-24)


### 🎉 Features

* Add Faro instrumentation ([#869](https://github.com/grafana/traces-drilldown/issues/869)) ([2edd9c9](https://github.com/grafana/traces-drilldown/commit/2edd9c93c8730e7e47475995e9e2976f8e8b0ac4))
* **breakdown:** reserve green for success, use blue for neutral rate ([#814](https://github.com/grafana/traces-drilldown/issues/814)) ([5486fe6](https://github.com/grafana/traces-drilldown/commit/5486fe668baf6fb49a3db885e54fa5205baf9472))


### 🐛 Bug Fixes

* always show panel menus and use secondary Include/Exclude buttons ([#873](https://github.com/grafana/traces-drilldown/issues/873)) ([d355e5b](https://github.com/grafana/traces-drilldown/commit/d355e5b00df716aad9dbe6df980497d0b2b2a417))
* dataframe for root cause latency could also be SearchResponse ([#752](https://github.com/grafana/traces-drilldown/issues/752)) ([957e4f7](https://github.com/grafana/traces-drilldown/commit/957e4f77dc0769e037cde4e4dc968f098ec29f1e))
* **deps:** bump pnpm overrides for CVE remediation ([#826](https://github.com/grafana/traces-drilldown/issues/826)) ([1e5bc09](https://github.com/grafana/traces-drilldown/commit/1e5bc099a2ee525049d9ab4d15957b346c7b961c))
* **deps:** bump pnpm overrides for CVE remediation ([#852](https://github.com/grafana/traces-drilldown/issues/852)) ([ab6a1a9](https://github.com/grafana/traces-drilldown/commit/ab6a1a9d8fbe1da79676dd7d8289e7dda5e2505e))
* **deps:** bump pnpm overrides for CVE remediation ([#857](https://github.com/grafana/traces-drilldown/issues/857)) ([968b017](https://github.com/grafana/traces-drilldown/commit/968b017f92c71aaae70d53c6e0487281622e92e3))
* **deps:** resolve pnpm audit vulnerabilities ([#819](https://github.com/grafana/traces-drilldown/issues/819)) ([5b51dab](https://github.com/grafana/traces-drilldown/commit/5b51dab256e755a4cac29f727b27960b2ba0588b))
* ignore attribute changes that are not human ([#853](https://github.com/grafana/traces-drilldown/issues/853)) ([a948c9b](https://github.com/grafana/traces-drilldown/commit/a948c9b62de3d0d87677247fd84c9602dcad1d53))
* preserve tab browser history ([#866](https://github.com/grafana/traces-drilldown/issues/866)) ([6270205](https://github.com/grafana/traces-drilldown/commit/62702058ba3aab4e56c0649d0b448ddd66b2a221))
* **release-please:** Update release-please action to version 2.0.2 ([#860](https://github.com/grafana/traces-drilldown/issues/860)) ([ec1266b](https://github.com/grafana/traces-drilldown/commit/ec1266bd4c9756b9ddcc8245710174b8f61e0afd))
* respect appSubUrl in trace-to-logs data links ([#785](https://github.com/grafana/traces-drilldown/issues/785)) ([b013dc7](https://github.com/grafana/traces-drilldown/commit/b013dc7f76dcd83e0a47c55d77a964c86b34541d))
* Scroll to trace in structure tab ([#827](https://github.com/grafana/traces-drilldown/issues/827)) ([66ecf28](https://github.com/grafana/traces-drilldown/commit/66ecf288993ae40eb8a11cf177f17fc59b0e06b9))
* **security/high/:** update pnpm to v11.8.0 [security] ([#804](https://github.com/grafana/traces-drilldown/issues/804)) ([31dd2a8](https://github.com/grafana/traces-drilldown/commit/31dd2a83881a286fbe1da194adad1a3f11e41f36))
* **security/medium/:** update dependency protobufjs to v7.6.5 [security] ([#817](https://github.com/grafana/traces-drilldown/issues/817)) ([c5bba01](https://github.com/grafana/traces-drilldown/commit/c5bba01320eac4c962f1033c9dbd998aaeda1290))
* **security/medium/:** update dependency react-router-dom to v6.30.5 [security] ([#859](https://github.com/grafana/traces-drilldown/issues/859)) ([fa64f59](https://github.com/grafana/traces-drilldown/commit/fa64f5905dd17700b9b702610065cb372495d8ff))
* **seeker:** keep relative range on refresh ([#834](https://github.com/grafana/traces-drilldown/issues/834)) ([81a1ad6](https://github.com/grafana/traces-drilldown/commit/81a1ad6bc7f31816f816f87cb8fab3e377098b53))
* **seeker:** keep resize handles updating range ([#846](https://github.com/grafana/traces-drilldown/issues/846)) ([5143690](https://github.com/grafana/traces-drilldown/commit/5143690e288770ceda199fd67abdc5bb99baa21e))
* stop duplicate history entries on load ([#849](https://github.com/grafana/traces-drilldown/issues/849)) ([f3c99d7](https://github.com/grafana/traces-drilldown/commit/f3c99d7cb495e144a3332b341e27552d7734a501))


### 📝 Documentation

* Add GenAI policy, contributor guide updates and issue templates ([#811](https://github.com/grafana/traces-drilldown/issues/811)) ([89a2a90](https://github.com/grafana/traces-drilldown/commit/89a2a90d8f5b7e9736104cf66711b22be3ccd4de))
* sync Traces Drilldown docs with v2.0.3 UI ([#828](https://github.com/grafana/traces-drilldown/issues/828)) ([2584b28](https://github.com/grafana/traces-drilldown/commit/2584b289d661e1bb78cb1e551355fed1e274b603))


### 🧪 Tests

* suppress i18next support notice ([#835](https://github.com/grafana/traces-drilldown/issues/835)) ([bcc1b79](https://github.com/grafana/traces-drilldown/commit/bcc1b798ed2ddab3453af328cf8628ffeff8325f))


### 🧹 Chore

* add CODEOWNERS file ([#851](https://github.com/grafana/traces-drilldown/issues/851)) ([a416a4b](https://github.com/grafana/traces-drilldown/commit/a416a4b11e079a7a2205df647b0b2ea77ed055d0))
* add cp-update workflow, bump action pins ([#868](https://github.com/grafana/traces-drilldown/issues/868)) ([78888f9](https://github.com/grafana/traces-drilldown/commit/78888f9059071aa7ae75463ee9e15380ceb728ab))
* add warnOnConflicts to i18next config ([#803](https://github.com/grafana/traces-drilldown/issues/803)) ([2788a81](https://github.com/grafana/traces-drilldown/commit/2788a81003374dc5bfd6387338e8f6a0bbe42210))
* **ci:** bump create-plugin-update to v2.0.3 ([#876](https://github.com/grafana/traces-drilldown/issues/876)) ([96ea43c](https://github.com/grafana/traces-drilldown/commit/96ea43c392d2afcbfabaaa5937af405b1039e441))
* **ci:** pass correct node version to Create Plugin Update ([#874](https://github.com/grafana/traces-drilldown/issues/874)) ([06aed90](https://github.com/grafana/traces-drilldown/commit/06aed9019c95d08dabdc4ab5234e8b4fae7124f5))
* **colors:** centralise metric colors and clean up overrides ([#836](https://github.com/grafana/traces-drilldown/issues/836)) ([9a4d455](https://github.com/grafana/traces-drilldown/commit/9a4d4555ffa23a802622606f7cccd4af61d08c73))
* **deps:** pin dependencies ([#808](https://github.com/grafana/traces-drilldown/issues/808)) ([e7866f8](https://github.com/grafana/traces-drilldown/commit/e7866f8e397470235f63eef39a4806e778294410))
* **deps:** update ghcr.io/grafana/xk6-client-tracing:latest docker digest to 94c45fd ([#809](https://github.com/grafana/traces-drilldown/issues/809)) ([a069efa](https://github.com/grafana/traces-drilldown/commit/a069efa3f40e79314a28b7dfab295eea6a1a228e))
* **deps:** update rabbitmq:management docker digest to 4e628d3 ([#832](https://github.com/grafana/traces-drilldown/issues/832)) ([5d1221f](https://github.com/grafana/traces-drilldown/commit/5d1221f5b26fa15d09c1ace99ba04d85e2bc4205))
* **deps:** update rabbitmq:management docker digest to 76412b1 ([#810](https://github.com/grafana/traces-drilldown/issues/810)) ([755e1eb](https://github.com/grafana/traces-drilldown/commit/755e1eb0dca8c22b3a926154ed1d5acd90b91e19))
* **e2e:** introduce proper tracesExplore fixture ([#855](https://github.com/grafana/traces-drilldown/issues/855)) ([0b8a8ee](https://github.com/grafana/traces-drilldown/commit/0b8a8ee79c9b1027986ae37cc3e4c93c4353b91a))
* **header:** use ToolbarButton for the plugin info button ([#824](https://github.com/grafana/traces-drilldown/issues/824)) ([efa4dc5](https://github.com/grafana/traces-drilldown/commit/efa4dc5e91289775e94f59c5e49f0527aef9d84f))
* Remove homepage ([#789](https://github.com/grafana/traces-drilldown/issues/789)) ([f27321f](https://github.com/grafana/traces-drilldown/commit/f27321f79835cd632aaf853df9c47d300a70089c))
* remove Inisights timeline widget ([#843](https://github.com/grafana/traces-drilldown/issues/843)) ([59ffbea](https://github.com/grafana/traces-drilldown/commit/59ffbeadf62323b14255be40e2628e4f28179138))
* Remove unused dependencies ([#830](https://github.com/grafana/traces-drilldown/issues/830)) ([d445639](https://github.com/grafana/traces-drilldown/commit/d4456391e7da4a67f794bcccf08442bf34478094))
* Update brace expansion ([#829](https://github.com/grafana/traces-drilldown/issues/829)) ([9ac3037](https://github.com/grafana/traces-drilldown/commit/9ac30374836121214d114525afd177443c226fb1))
* update dependencies ([#838](https://github.com/grafana/traces-drilldown/issues/838)) ([36055b4](https://github.com/grafana/traces-drilldown/commit/36055b4d9ca7171dffad181f11c8e80a3f5efc59))
* Wrap RED toggles in small screen ([#805](https://github.com/grafana/traces-drilldown/issues/805)) ([a2a3226](https://github.com/grafana/traces-drilldown/commit/a2a32269218574f4b3ec647493da54eb7cf786ca))

## [2.1.0](https://github.com/grafana/traces-drilldown/compare/v2.0.4...v2.1.0) (2026-06-30)


### 🎉 Features

* Exceptions tab grouping ([#756](https://github.com/grafana/traces-drilldown/issues/756)) ([c119dab](https://github.com/grafana/traces-drilldown/commit/c119dab0085c457bbfc89823fbc5a72fb84b5fa2))


### 🐛 Bug Fixes

* **deps:** bump dompurify override to ^3.4.11 for CVE remediation ([#792](https://github.com/grafana/traces-drilldown/issues/792)) ([fb1005d](https://github.com/grafana/traces-drilldown/commit/fb1005d5c6fec6da5423daeeb98fbe5d9ca47c33))


### 🤖 Continuous Integrations

* **release-please:** add release please ([#790](https://github.com/grafana/traces-drilldown/issues/790)) ([acd2986](https://github.com/grafana/traces-drilldown/commit/acd2986b8af197196ec2abd20c0daeecab90a164))


### 🧹 Chore

* **ci/cd:** update to 10.1.0 ([#795](https://github.com/grafana/traces-drilldown/issues/795)) ([227255d](https://github.com/grafana/traces-drilldown/commit/227255dfadeb22484a096dbf36693a816d37839a))
* **ci:** Update release workflows ([#806](https://github.com/grafana/traces-drilldown/issues/806)) ([8e02d22](https://github.com/grafana/traces-drilldown/commit/8e02d22b23bc817adf66bc62e953cfd609011fd4))
* Create new plugin info menu ([#757](https://github.com/grafana/traces-drilldown/issues/757)) ([0535132](https://github.com/grafana/traces-drilldown/commit/05351329e7b64b749bfbe8fec2f7e2859fbb9ac5))
* **deps:** bump @openfeature/ofrep-web-provider from 0.3.5 to 0.4.1 ([#776](https://github.com/grafana/traces-drilldown/issues/776)) ([589825e](https://github.com/grafana/traces-drilldown/commit/589825e315ba3118d5aa4a9afeb5ce05c5289446))
* **deps:** update grafana/tempo:latest docker digest to 1ce31d6 ([#767](https://github.com/grafana/traces-drilldown/issues/767)) ([d536388](https://github.com/grafana/traces-drilldown/commit/d53638819dc08da634bfc5da4de92d762c8c881a))
* **deps:** update rabbitmq:management docker digest to f2aa009 ([#769](https://github.com/grafana/traces-drilldown/issues/769)) ([fbcef1a](https://github.com/grafana/traces-drilldown/commit/fbcef1a327e59fb89074e8bea3be58e34747f0c4))
* Pin node version in bundle-types ([#778](https://github.com/grafana/traces-drilldown/issues/778)) ([80867c7](https://github.com/grafana/traces-drilldown/commit/80867c739f1a38811d7e3a532141da5501f565a4))
* Remove publish-technical-documentation workflows ([#791](https://github.com/grafana/traces-drilldown/issues/791)) ([6eb1c08](https://github.com/grafana/traces-drilldown/commit/6eb1c08c62f6dd055ae9b2aba2c1e6012fd2c1ce))
* Update Grafana packages to 12.4.3 ([#749](https://github.com/grafana/traces-drilldown/issues/749)) ([4ce0ad9](https://github.com/grafana/traces-drilldown/commit/4ce0ad920f5a433a0a2cce68f76cfbcc7ff04c2a))
* Update packages ([#786](https://github.com/grafana/traces-drilldown/issues/786)) ([e415046](https://github.com/grafana/traces-drilldown/commit/e4150463f1523788e165a9fa1690aab220614059))
* Workflows update ([#764](https://github.com/grafana/traces-drilldown/issues/764)) ([f02765b](https://github.com/grafana/traces-drilldown/commit/f02765bd2b265df9a0dc06e44d33d63298a80c5c))

## 2.0.4

##### Chores

*  Update ci-cd-workflows (#762) (d5f4fdcd)
*  update Saved queries texts (#773) (cef85d98)
*  Harden package use and workspace environment (#761) (bb50beee)
*  Improve e2e testing (#755) (8426e7a8)
* **deps:**
  *  update dependency @playwright/test to v1.59.1 (#704) (6c6357d8)
  *  lock file maintenance (#711) (e18c0a12)
  *  bump fast-uri from 3.1.0 to 3.1.2 (#751) (1794aa09)
  *  pin dependencies (#741) (a000d785)
  *  update grafana/plugin-actions digest to 016148f (#742) (04322201)

##### New Features

*  Support add to dashboard (#746) (640fc4b2)
*  Enhance Embedded Traces Drilldown (#744) (6cf5e6d0)
*  Support create alert (#747) (cf4d73a6)

##### Bug Fixes

*  update Crowdin workflows to use fromJSON secrets output (#775) (e2170753)
*  syncing of y axis (#754) (2c6a21a9)

##### Other Changes

*  Download translations from Crowdin (#732) (d46cc150)


## 2.0.3

##### Build System / Dependencies

*  add pull request template file (#737) (c6e9b66b)
*  migrate to pnpm (#722) (c9c2ed25)

##### Chores

*  fix @tootallnate/once CVE-2026-3449 via pnpm override (#736) (3f5dbaff)
*  fix CVE warnings (#733) (8f3fd8ee)
*  Fix flaky test (#724) (779f1509)
*  Use OpenFeature for all feature flags (#713) (11958ffe)
*  bump Node.js requirement to 22 (#721) (8e7f11d9)
* **i18n:**
  *  add Crowdin GitHub Actions workflows (#726) (b6afa0c7)
  *  add ESLint rules and translate all user-facing strings (#725) (7f5d5c0e)
  *  add @grafana/i18n infrastructure (#718) (5cc3fe48)

##### New Features

*  add Knowledge Graph insights annotations to timeseries (#685) (6e10303b)

##### Bug Fixes

* **ci:**  consolidate CI/CD into single workflow to fix deploy race condition (#739) (deab60e0)
*  ensure AttributesSidebar displays correctly on smaller screens (#728) (7fd6a4ea)
*  add webpack alias for `@grafana/i18n` to prevent pnpm module duplication (#735) (50273acb)
*  gate deploy on CI success via `workflow_run` (#734) (e8426e3b)
*  Escape filters with newlines etc (#723) (ee3778b7)
* **i18n:**  use correct i18next-cli binary and config format (#730) (21fde20d)


## 2.0.2

##### Chores

*  Add refresh control to embedded header (#716) (510b360b)
* **deps:**
  *  bump protocol-buffers-schema from 3.6.0 to 3.6.1 (#717) (b07a4926)
  *  bump protobufjs from 7.5.4 to 7.5.5 (#719) (96ce8403)


## 2.0.1

##### Build System / Dependencies

*  add support for mise package manager (#684) (53ede010)

##### Chores

* **deps:**
  *  update dependency dompurify to v3.4.0 [security] (#715) (3296adb8)
  *  update dependency knip to v5.88.1 (#706) (2536ab60)
  *  update dependency @types/node to v22.19.15 (#705) (47eacfa9)
  *  update dependency lodash to v4.18.1 [security] (#707) (5f7b8089)
  *  update dependency sass-loader to v16.0.7 (#699) (3abf9f9a)
  *  update dependency nwsapi to v2.2.23 (#698) (0b73206c)
  *  update dependency semver to v7.7.4 (#700) (c392be0a)
  *  update swc monorepo (#701) (f7ade26d)
  *  update dependency @types/lodash to v4.17.24 (#695) (865c175f)
  *  update dependency css-loader to v7.1.4 (#696) (937d0b6a)
  *  update dependency eslint-plugin-jsdoc to v62.8.1 (#697) (62e3f515)
  *  update rabbitmq:management docker digest to 23fe4f2 (#694) (baa8d266)
  *  update grafana/tempo:latest docker digest to 112d818 (#693) (99d2c503)
  *  pin dependencies (#660) (79e5589c)
  *  lock file maintenance (#652) (fc21531c)
  *  update grafana/tempo:latest docker digest to 5aa154f (#663) (c8bf14cc)
  *  update grafana/intro-to-mltp:mythical-beasts-recorder-latest docker digest to 82cd149 (#662) (c83d2803)
*  Remove unused dependencies (#675) (88e7ff7b)
* **eslint:**  migrate to ESLint 9 flat config (#681) (c7eed48c)

##### Documentation Changes

*  Update for Include/Exclude, Adaptive Traces tab, and time seeker (#709) (aea3d093)
*  Update for save queries (#688) (e59eb9b5)

##### New Features

*  Time range seeker (#611) (eb283c9d)
*  Support include / exclude for panels (#624) (5edbe889)

##### Bug Fixes

*  upgrade `terser-webpack-plugin` to resolve CVE (#714) (bfe4c44d)
*  Fix issue with logsDrilldownExtension.fn (#708) (d2264fde)
*  add packages to resolutions in package.json (#683) (8f24f6b0)
*  update levignore to pass grafana runtime compatibility check (#682) (5c097dff)
* **deps:**  update resolutions to fix `yarn audit` vulnerabilities (#690) (ca57dd08)


## 2.0.0

##### Chores

* **deps:**
  *  fix all dependency vulnerabilities (minimatch, ajv, @tootallnate/once) (#674) (d9168e50)
  *  bump undici from 7.18.2 to 7.24.4 (#669) (2f771b89)
*  Fix release action (#672) (f5326ea7)

##### Documentation Changes

*  Update Traces Drilldown doc and screenshots (#670) (f655b157)

##### New Features

*  Add AGENTS.md and surrounding files (#671) (ea7313bf)
*  Support Saved Queries (#653) (1ad5ea70)


## 1.4.1


## 1.4.0

##### Chores

*  React 19 upgrade (#666) (e9db5d4f)


## 1.3.3

##### Chores

*  Resolve react-router (#665) (23f24805)
*  Remove spellcheck (#648) (03e5068c)
*  Update brace expansion (#644) (3efce86e)
* **deps:**
  *  bump qs from 6.14.1 to 6.14.2 (#651) (90247275)
  *  update actions/checkout digest to 34e1148 (#636) (3564c51d)
  *  update grafana/grafana-enterprise:latest docker digest to 9dedb4a (#637) (26e31535)
  *  update grafana/intro-to-mltp:mythical-beasts-recorder-latest docker digest to 1420cd8 (#638) (4867cbde)
  *  pin dependency @testing-library/react to 16.3.1 (#635) (0ee83dc4)
* **deps-dev:**  bump webpack from 5.101.0 to 5.104.1 (#647) (bcd785df)

##### New Features

*  Hide baseline only panels in the comparison tab (#664) (56a7e3eb)
*  Enhanced exceptions tab (#627) (733eec3d)
*  Send filters to EntityAssertionsWidget (#626) (057ddf2e)

##### Bug Fixes

*  resolves the addition of extra pipelines in trace explorer (#650) (24f820d9)


## 1.3.2

##### Chores

*  Upgrade lodash (#643) (433559b)


## 1.3.1

##### Chores

*  Upgrade react-router (#621) (eec1df9e)

##### Bug Fixes

*  Check if usePluginFunctions is available (#616) (99112e44)


## 1.3.0

##### Chores

* **deps:**
  *  update dependency @babel/core to v7.28.5 (#577) (3dfd3cd5)
  *  update swc monorepo (#580) (8f14d360)
  *  update grafana/tempo:latest docker digest to 6d4f1f3 (#599) (8f747508)
*  Update grafana to 12.3.0 (#609) (deb155f2)
* **config:**  migrate config renovate.json (#607) (aee65df3)

##### Continuous Integration

*  Update workflow permissions (#623) (0269bfc5)

##### Documentation Changes

*  Minor updates to docs (#608) (af917d5d)

##### New Features

*  Show favorites first in the attribute sidebar (#625) (975e40c6)
*  Exceptions Tab v2 (#619) (7ee82314)
*  Adaptive Traces Integration (#614) (c3c77e68)
* **links:**  grafana assistant traces drilldown full query navigation (#541) (64e42e8e)


## 1.2.1

##### Chores

*  Add Renovate rules (#606) (d836c42a)
* **deps:**
  *  update dependency nwsapi to v2.2.22 (#572) (07865f22)
  *  pin dependencies (#569) (f3353005)

##### Documentation Changes

*  Exception tab (#585) (364fe32e)
*  Doc updates for 554, 558, and 555 (#564) (68d41f9c)

##### New Features

*  Mini embeddable Traces Drilldown (#592) (7aecc60e)
*  Find single span errors and high latency on the root cause tab (#594) (db46387a)
*  Link to Logs Drilldown instead of Explore (#563) (6ea96dd3)


## 1.2.0

##### Chores

*  add annotation topic to annotation frame (#560) (e9856325)

##### New Features

*  Attributes sidebar (#558) (7ed0f3c8)
*  View trace by ID input (#555) (6a8d0cfe)
*  Percentiles variable for duration breakdown (#554) (69e3ab05)


## 1.1.4

##### Chores

*  Support quoted numeric strings (#552) (c9120937)
*  Update create-plugin (#539) (b540db0e)
*  updates readme to reflect GA status. (#540) (4c928873)

##### New Features

*  Integrate Insights Timeline widget (#543) (8853aa3a)

##### Performance Improvements

*  Use new TraceQL sampling hint for RED panels (#547) (b68d6c64)


## 1.1.3

##### Chores

*  Exceptions tab improvements (#535) (7cf574e6)
*  Update Grafana packages (#511) (b89ef3cb)

##### New Features

*  Trace exploration improvements (#537) (a8704e8d)
*  Exceptions tab (#509) (c259a96f)

##### Bug Fixes

*  Fix date formatting when rounded (#529) (3593aaa7)
*  Fix duplicate title and close button in drawer (#507) (6b4527be)


## 1.1.2

##### Chores

*  changing input props for exposed component (#462) (0cf77202)
*  isolate types imports for exposed component (#460) (fdb54e47)
*  remove extension link from logs drilldown (#421) (9a8efe9e)
*  update bundle-types.yml (#347) (7403a7ec)

##### Continuous Integration

*  Add conventional commits workflow and improve release (#506) (81897aa4)

##### New Features

*  open in explore traces button (#335) (d7d91db3)
* **explorations:**  rename to `investigations` (#340) (651373d2)

##### Bug Fixes

* **500:**  Use db.system.name instead of db.name attribute for the "Database calls" filter (#501) (06b298d4)
* **PanelMenu:**  use `firstValueFrom()` instead of `lastValueFrom()` (#399) (e343d6a9)
* **open in drilldown button:**  update tempo matcher type (#376) (78aceb98)

##### Other Changes

*  create a new history item when a filter is added from the breakdown (#431) (edb3f1af)
*  Do not show an empty state while streaming is still in progress (#426) (b877d479)
*  update error panel y-axis labels (#424) (6236467b)
*  Add "Go Queryless" hook (#404) (18319c97)
*  Make extensions compatible with different Grafana versions (#395) (b045de36)


## [1.1.0](https://github.com/grafana/traces-drilldown/compare/v1.0.0...v1.1.0) (2025-06-27)

* Default to all spans when pressing Open in Traces Drilldown button ([#443](https://github.com/grafana/traces-drilldown/pull/443))
* Fix broken links in docs ([#447](https://github.com/grafana/traces-drilldown/pull/447))
* Fix zizmor detected template-injection issues ([#450](https://github.com/grafana/traces-drilldown/pull/450))
* Style error panels according to metric ([#449](https://github.com/grafana/traces-drilldown/pull/449))
* Work around ref URIs bug ([#457](https://github.com/grafana/traces-drilldown/pull/457))
* New exposed component to embed the trace exploration scene ([#407](https://github.com/grafana/traces-drilldown/pull/407))
* Fix Zizmor persist credentials issues ([#456](https://github.com/grafana/traces-drilldown/pull/456))
* Fix exposing types ([#459](https://github.com/grafana/traces-drilldown/pull/459))
* chore: isolate types imports for exposed component ([#460](https://github.com/grafana/traces-drilldown/pull/460))
* chore: changing input props for exposed component ([#462](https://github.com/grafana/traces-drilldown/pull/462))
* Embedded mode improvements ([#466](https://github.com/grafana/traces-drilldown/pull/466))
* Bring back all primary signals ([#472](https://github.com/grafana/traces-drilldown/pull/472))
* Upgrade packages ([#476](https://github.com/grafana/traces-drilldown/pull/476))
* Update policy token to use env variable from Vault ([#473](https://github.com/grafana/traces-drilldown/pull/473))
* Embedded mode improvements ([#477](https://github.com/grafana/traces-drilldown/pull/477))
* UPreserve asserts context via embedded assertions widget component ([#464](https://github.com/grafana/traces-drilldown/pull/464))
* Fix Zizmor issues ([#483](https://github.com/grafana/traces-drilldown/pull/483))
* Type string booleans as booleans unless user has put them in quotes ([#482](https://github.com/grafana/traces-drilldown/pull/482))
* Embedded mode fixes + improvements ([#484](https://github.com/grafana/traces-drilldown/pull/484))
* Explain selection vs baseline when 'Span rate' metric is chosen ([#487](https://github.com/grafana/traces-drilldown/pull/487))
* Update @grafana/scenes to 6.23.0 ([#488](https://github.com/grafana/traces-drilldown/pull/488))
* Add namespace to embedded app ([#489](https://github.com/grafana/traces-drilldown/pull/489))

## [1.0.0](https://github.com/grafana/traces-drilldown/compare/v0.2.9...v1.0.0) (2025-04-24)

* Breakdown: Do not show an empty state while streaming is still in progress. ([#426](https://github.com/grafana/traces-drilldown/pull/426))
* Add support for contextualised trace list table. ([#409](https://github.com/grafana/traces-drilldown/pull/409))
* Move version to menu and remove preview badge. ([#429](https://github.com/grafana/traces-drilldown/pull/429))
* Add fix to show empty state in the trace list. ([#430](https://github.com/grafana/traces-drilldown/pull/430))
* Fix to normalize comparison data when total fields are missing or invalid. ([#435](https://github.com/grafana/traces-drilldown/pull/435))
* Breakdown: create a new history item when a filter is added from the breakdown. ([#431](https://github.com/grafana/traces-drilldown/pull/431))

## [0.2.9](https://github.com/grafana/traces-drilldown/compare/v0.2.8...v0.2.9) (2025-04-15)

* Remove exemplars from heatmap. ([#398](https://github.com/grafana/traces-drilldown/pull/398))
* Filter out redundant attributes. ([#397](https://github.com/grafana/traces-drilldown/pull/397))
* Show warning if datasource is not configured with TraceQL metrics. ([#400](https://github.com/grafana/traces-drilldown/pull/400))
* Ensure Y-axis label matches the data for RED metrics. ([#401](https://github.com/grafana/traces-drilldown/pull/401))
* Explore: Add "Go Queryless" hook. ([#404](https://github.com/grafana/traces-drilldown/pull/404))
* Fix issue with container height. ([#422](https://github.com/grafana/traces-drilldown/pull/422))
* Use events to open traces. ([#410](https://github.com/grafana/traces-drilldown/pull/410))
* chore: remove extension link from logs drilldown. ([#421](https://github.com/grafana/traces-drilldown/pull/421))
* Fix structure tab flickering. ([#394](https://github.com/grafana/traces-drilldown/pull/394))
* Support typed query generation. ([#423](https://github.com/grafana/traces-drilldown/pull/423))
* RED Panels: update error panel y-axis labels. ([#424](https://github.com/grafana/traces-drilldown/pull/424))
* Rename plugin extension link from Explore to Drilldown. ([#425](https://github.com/grafana/traces-drilldown/pull/425))
* Add support for adding a trace to investigations. ([#408](https://github.com/grafana/traces-drilldown/pull/408))

## [0.2.6](https://github.com/grafana/traces-drilldown/compare/v0.2.4...v0.2.6) (2025-03-12)

### Enhancements

* Support for add to investigation. ([#320](https://github.com/grafana/traces-drilldown/pull/320))
* Support for metrics streaming. ([#312](https://github.com/grafana/traces-drilldown/pull/312))
* Rename plugin to Grafana Traces Drilldown. ([#329](https://github.com/grafana/traces-drilldown/pull/329))
* Add back and forward support for app actions. ([#294](https://github.com/grafana/traces-drilldown/pull/294))
* Exposes a component which takes properties and creates a LinkButton with a href to navigate to the Traces Drilldown from outside. ([#335](https://github.com/grafana/traces-drilldown/pull/335))
* Select custom columns in trace list. ([#342](https://github.com/grafana/traces-drilldown/pull/342))

## [0.2.3](https://github.com/grafana/explore-traces/compare/v0.2.2...v0.2.3) (2025-02-06)

### Enhancements

* **Open trace in drawer:** The traces now open in a drawer which should improve the experience of analysing the details of a trace. ([#325](https://github.com/grafana/explore-traces/pull/325))

### Bug Fixes

* Fixes crash on main metric panel ([#317](https://github.com/grafana/explore-traces/pull/317))

## [0.2.2](https://github.com/grafana/explore-traces/compare/v0.2.0...v0.2.2) (2025-01-13)

### Enhancements

* **Custom values in filters bar:** The filters bar now allows custom values which can be used to build regular expressions or input values missing from the dropdown options. ([#288](https://github.com/grafana/explore-traces/pull/252))

## [0.2.0](https://github.com/grafana/explore-traces/compare/v0.1.3...v0.2.0) (2025-01-10)

### Features

* **Support for exemplars:** Quickly jump to the relevant data points or logs for deeper troubleshooting with newly added support for exemplars, directly on your metrics graph. By clicking on a point of interest on the graph—like a spike or anomaly—you can quickly jump to the relevant traces for deeper troubleshooting and dramatically reduce the time it takes to root cause an issue. ([#278](https://github.com/grafana/explore-traces/pull/278)) Requires Grafana >= 11.5.0
* **Open traces in Explore:** When viewing trace spans, now you can easily open the full trace in Explore. This provides a streamlined way to pivot between trace analysis and the broader Grafana Explore experience without losing context. ([#267](https://github.com/grafana/explore-traces/pull/267))

### Enhancements

* **Trace breakdown adjusts better to smaller screens:** The **Breakdown** tab now automatically adjusts its attribute selector display based on available screen width, improving usability on smaller viewports. ([#267](https://github.com/grafana/explore-traces/pull/267))
* **Search is now case-insensitive:** Search in the **Breakdown** and **Comparison** tabs now ignores capitalization, ensuring you see all matching results. ([#252](https://github.com/grafana/explore-traces/pull/252))
* **Performance boost and reduced bundle size**: Code-splitting and lazy loading for faster loading times. Only the modules you need are fetched on demand, cutting down on initial JavaScript payload and improving app performance. ([#275](https://github.com/grafana/explore-traces/pull/275))
* **Various fixes and improvements:** Fixed loading and empty states. Fixed broken documentation link. Refined styles above filters for a more polished look. Added descriptive text to the Span List tab for added clarity. Enhanced tooltip design for RED metrics. Standardized error messages and titles, plus added helpful hints when an empty state appears. ([#263](https://github.com/grafana/explore-traces/pull/263))

## 0.1.2

Release public preview version.
